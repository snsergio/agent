#include <stdlib.h>
#include <iostream>
#include <signal.h>
#include <fstream>
#include <string>
#include <filesystem>
namespace fs = std::filesystem;

#include <sys/resource.h>
#include <termios.h>
#include <glog/logging.h>
#include <nlohmann/json.hpp>
using json = nlohmann::json;

#include "version.h"

// Mongo
#include <mongocxx/instance.hpp>
#include "flow_process.h"

json g_eyeflow_conf;
struct termios oldSettings, newSettings;
// --------------------------------------------------------------------------------------------------------------------------------

bool g_thread;

void signal_handler(int sig)
{
    LOG(INFO) << "Caught signal: " << sig;
    switch(sig)
    {
        case SIGINT:
            tcsetattr(fileno(stdin), TCSANOW, &oldSettings);
            LOG(INFO) << "SIGINT";
            g_thread = false;

            break;
            // exit(0);

        case SIGKILL:
            tcsetattr(fileno(stdin), TCSANOW, &oldSettings);
            LOG(INFO) << "Stopping";
            break;
            // exit(1);

        default:
            LOG(INFO) << "Unknown signal: " << sig;
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

void load_config()
{
    fs::path filename = "eyeflow_conf.json";
    if (!fs::is_regular_file(filename))
        throw std::runtime_error("Conf file not found [" + filename.string() + "]");

    std::ifstream fp;
    fp.open(filename);
    if (!fp)
    {
        std::string err_msg = "Failed to open " + filename.string() + " - " + std::strerror(errno);
        LOG(ERROR) << err_msg;
        throw std::system_error(errno, std::system_category(), err_msg);
    }

    g_eyeflow_conf = json::parse(fp);
    fp.close();
}
// --------------------------------------------------------------------------------------------------------------------------------

void initialize(json flow_data)
{
    // Init Mongo
    mongocxx::instance instance{}; // This should be done only once.

    // Init CUDA
    setenv("CUDA_MODULE_LOADING", "LAZY", 0);
}
// --------------------------------------------------------------------------------------------------------------------------------

int main(int argc, char* argv[])
{
    load_config();

    struct rlimit core_limits;
    core_limits.rlim_cur = core_limits.rlim_max = RLIM_INFINITY;
    setrlimit(RLIMIT_CORE, &core_limits);

    tcgetattr(fileno(stdin), &oldSettings);

    FLAGS_log_dir = g_eyeflow_conf["log"]["log_folder"].get<std::string>();
    FLAGS_alsologtostderr = 1;
    google::SetLogFilenameExtension(".log");
    google::InitGoogleLogging(argv[0]);

    struct sigaction sigIntHandler;
    sigIntHandler.sa_handler = signal_handler;
    sigemptyset(&sigIntHandler.sa_mask);
    sigIntHandler.sa_flags = 0;
    sigaction(SIGINT, &sigIntHandler, NULL);

    try
    {
        LOG(INFO) << "Eyeflow Edge " << VERSION;

        fs::path edge_data_filename(g_eyeflow_conf["file-service"]["data_folder"].get<std::string>());
        edge_data_filename.append("edge_data.json");
        if (!fs::is_regular_file(edge_data_filename))
            throw std::runtime_error("Edge data file not found. Need to update from Eyeflow.AI cloud. [" + edge_data_filename.string() + "]");

        std::ifstream fp;
        fp.open(edge_data_filename);
        if (!fp)
        {
            std::string err_msg = "Failed to open " + edge_data_filename.string() + " - " + strerror(errno);
            LOG(ERROR) << err_msg;
            throw std::system_error(errno, std::system_category(), err_msg);
        }

        json edge_data = json::parse(fp);
        fp.close();

        LOG(INFO) << "EyeflowEdge [" + edge_data["edge_data"]["name"].get<std::string>() + "] - " + edge_data["edge_data"]["_id"].get<std::string>();
        LOG(INFO) << "Running flow [" + edge_data["edge_data"]["flow_name"].get<std::string>() + "] - " + edge_data["edge_data"]["flow_id"].get<std::string>() + " - Last modified: " + edge_data["edge_data"]["flow_modified_date"].get<std::string>();

        fs::path flow_filename(g_eyeflow_conf["file-service"]["flow"].get<std::string>());
        flow_filename.append(edge_data["edge_data"]["flow_id"].get<std::string>() + ".json");
        if (!fs::is_regular_file(flow_filename))
            throw std::runtime_error("Flow data file not found. Need to update from Eyeflow.AI cloud. [" + flow_filename.string() + "]");

        fp.open(flow_filename);
        if (!fp)
        {
            std::string err_msg = "Failed to open " + flow_filename.string() + " - " + strerror(errno);
            LOG(ERROR) << err_msg;
            throw std::system_error(errno, std::system_category(), err_msg);
        }

        json flow_data = json::parse(fp);
        fp.close();

        json process_parms = {
            {"service", false},
            {"monitor", false},
            {"video_save", false},
            {"flow_test", false},
            {"video_test", false},
            {"image_test", false},
            {"video_file", ""},
            {"video_path", g_eyeflow_conf["file-service"]["video"].get<std::string>()},
            {"image_path", g_eyeflow_conf["file-service"]["dataset"].get<std::string>()}
        };

        for (int arg = 1; arg < argc; arg++)
        {
            std::string opt = std::string(argv[arg]);
            if (opt == "--service")
            {
                process_parms["service"] = true;
                LOG(INFO) << "Service=true";
            }
            else if (opt == "--monitor")
            {
                process_parms["monitor"] = true;
                LOG(INFO) << "Monitor=true";
            }
            else if (opt == "--video_save")
            {
                process_parms["video_save"] = true;
                LOG(INFO) << "VideoSave=true";
            }
            else if (opt == "--image_save")
            {
                process_parms["image_save"] = true;
                LOG(INFO) << "ImageSave=true";
            }
            else if (opt.substr(0, 13) == "--video_path=")
            {
                process_parms["video_path"] = opt.substr(13, opt.size());
                LOG(INFO) << "VideoPath=" << process_parms["video_path"].get<std::string>();
            }
            else if (opt.substr(0, 13) == "--image_path=")
            {
                process_parms["image_path"] = opt.substr(13, opt.size());
                LOG(INFO) << "ImagePath=" << process_parms["image_path"].get<std::string>();
            }
            else if (opt == "--image_test")
            {
                process_parms["flow_test"] = true;
                process_parms["image_test"] = true;
            }
            else if (opt == "--video_test")
            {
                process_parms["flow_test"] = true;
                process_parms["video_test"] = true;
                process_parms["video_file"] = json::object();
                while ((arg + 1) < argc)
                {
                    arg++;
                    std::string input = std::string(argv[arg]);
                    int idx = input.find('=', 0);
                    if (idx > 0)
                        process_parms["video_file"][input.substr(0, idx)] = input.substr(idx + 1, 100);
                    else
                        break;
                }

                LOG(INFO) << "VideoTest = " << process_parms["video_file"].dump();
            }
            else
            {
                LOG(ERROR) << "Invalid option: " << opt;
                LOG(ERROR) << "Usage: eyeflow_edge [--monitor] [--video_save] [--image_path=/opt/eyeflow/data/dataset/] [--image_test] [--video_path=/path/] [--video_test] <input_name=video_file.avi>";
                return 1;
            }
        }

        initialize(flow_data);

        FlowProcess flow_processor(flow_data, process_parms);
        g_thread = true;
        flow_processor.process_flow(&g_thread);
    }
    catch(std::exception& excpt)
    {
        LOG(ERROR) << "Fail processing flow: " << excpt.what();
        tcsetattr(fileno(stdin), TCSANOW, &oldSettings);
        return 1;
    }
    catch(...)
    {
        tcsetattr(fileno(stdin), TCSANOW, &oldSettings);
        LOG(ERROR) << "Fail processing flow";
        return 1;
    }

    tcsetattr(fileno(stdin), TCSANOW, &oldSettings);
    return 0;
}
// --------------------------------------------------------------------------------------------------------------------------------
