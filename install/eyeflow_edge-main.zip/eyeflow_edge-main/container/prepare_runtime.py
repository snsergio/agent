#!/usr/bin/python3

import subprocess, sys, os
import shutil
import argparse
#----------------------------------------------------------------------------------------------------------------------------------

def ldd(exe, dest_path):
    output = None
    # run ldd in command line
    try:
        output = subprocess.check_output("ldd " + exe, stderr=subprocess.STDOUT, shell=True)
    except subprocess.CalledProcessError as e:
        print(e.output)
        return

    os.makedirs(dest_path, exist_ok=True)
    outputlines = output.decode().splitlines()
    for line in outputlines:
        elem = line.split()
        if len(elem) != 4:
            continue

        if os.path.isfile(dest_path + elem[0]):
            continue

        if elem[2] == "not" and elem[3] == "found":
            print(f"File not found: {elem[0]}")
            continue

        print(f"Copying: {elem[0]}")
        shutil.copyfile(elem[2], dest_path + elem[0])

    extra_files = [
        '/opt/TensorRT-8.5.3.1/targets/x86_64-linux-gnu/lib/libnvinfer.so.8',
        '/opt/TensorRT-8.5.3.1/targets/x86_64-linux-gnu/lib/libnvinfer_plugin.so.8',
        '/opt/TensorRT-8.5.3.1/targets/x86_64-linux-gnu/lib/libnvinfer_builder_resource.so.8.5.3'
    ]
    for file in extra_files:
        if not os.path.isfile(f"{dest_path}/" + os.path.basename(file)):
            print(f"Copying {file}")
            shutil.copy(file, dest_path)
#----------------------------------------------------------------------------------------------------------------------------------

def parse_args(args):
    """ Parse the arguments.
    """
    parser = argparse.ArgumentParser(description='Check Datasets DB.')
    parser.add_argument('--src', help='Source path', type=str, default="/home/eyeflow_edge/")
    parser.add_argument('--dst', help='Destiny path', type=str, default="/home/container/")

    return parser.parse_args(args)
#----------------------------------------------------------------------------------------------------------------------------------

args = sys.argv[1:]
args = parse_args(args)
print(f"Copying files from {args.src} to {args.dst}...")

exe_file = args.src + "/build/eyeflow_edge"
ldd(exe_file, f"{args.dst}/lib/")
