import datetime
import json
import platform
#----------------------------------------------------------------------------------------------------------------------------------


def get_device_arch():
    plat_info = platform.platform().split('-')
    if plat_info[0] != "Linux":
        raise Exception(f"Invalid platform: {plat_info[0]}")

    if "aarch64" in plat_info:
        idx = plat_info.index("aarch64")
        return f"{plat_info[idx]}"
    elif "x86_64" in plat_info:
        idx = plat_info.index("x86_64")
        return f"{plat_info[idx]}"
#----------------------------------------------------------------------------------------------------------------------------------


with open("../version.h", 'r') as fp:
    text = fp.readlines()

with open("../version.h", 'w') as fp:
    for lin in text:
        if lin.startswith("#define VERSION"):
            old_version = lin.split()[-1]
            old_version = old_version.replace('"', '')
            inc_version = [int(v) for v in old_version.split('.')]
            version = f"{inc_version[0]}.{inc_version[1]}.{inc_version[2] + 1}"
            new_version = f'#define VERSION "{version}"'
            fp.write(new_version)
        else:
            fp.write(lin)

pack_id = "64fb7933f257ab6cb37ce65d"
gen_date = datetime.datetime.now(datetime.timezone.utc)
# version_date = f'{gen_date.isoformat()[2:4]}{gen_date.isoformat()[5:7]}{gen_date.isoformat()[8:10]}{gen_date.isoformat()[11:13]}{gen_date.isoformat()[14:16]}'

manifest = {
    "name": "eyeflow_edge",
    "version": version,
    "arch": get_device_arch(),
    "pack_id": pack_id,
    "compilation_date": gen_date
}

with open("../build/manifest.json", 'w') as fp:
    json.dump(manifest, fp, indent=2, default=str)
