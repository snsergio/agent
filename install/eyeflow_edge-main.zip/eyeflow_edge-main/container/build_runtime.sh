IMAGE=eyeflow_edge
VERSION=$(git rev-parse --short HEAD)-$(date +%y%m%d%H%M)
echo "Creatin Image eyeflowai/$IMAGE:$VERSION"
docker build -t eyeflowai/$IMAGE:$VERSION -f dockerfile_runtime .
docker push eyeflowai/$IMAGE:$VERSION
docker tag eyeflowai/$IMAGE:$VERSION eyeflowai/$IMAGE:latest
docker push eyeflowai/$IMAGE:latest

# docker run --gpus=all --rm -d --volume /data/eyeflow/data:/opt/eyeflow/data --volume /data/eyeflow/log:/opt/eyeflow/log --volume /data/eyeflow/run/edge.license:/opt/eyeflow/run/edge.license eyeflowai/eyeflow_edge
# docker run --gpus=all --rm  -it --volume /data/eyeflow/data:/opt/eyeflow/data --volume /data/eyeflow/log:/opt/eyeflow/log --volume /data/eyeflow/run/edge.license:/opt/eyeflow/run/edge.license eyeflowai/eyeflow_edge bash
# docker run --gpus=all --rm --name eyeflow_edge --volume /opt/eyeflow/data:/opt/eyeflow/data --volume /opt/eyeflow/log:/opt/eyeflow/log --volume /opt/eyeflow/run/edge.license:/opt/eyeflow/run/edge.license --volume /opt/eyeflow/run/edge-key.pub:/opt/eyeflow/run/edge-key.pub --volume /opt/spinnaker:/opt/spinnaker --env FLIR_GENTL64_CTI=/opt/spinnaker/lib/flir-gentl/FLIR_GenTL.cti --device=/dev/bus/usb/002/002 eyeflowai/eyeflow_edge
