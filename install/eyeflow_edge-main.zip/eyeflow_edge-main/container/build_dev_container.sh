az acr login -n eyeflow
docker build -t eyeflow.azurecr.io/eyeflow_dev -f dockerfile_dev .
docker push eyeflow.azurecr.io/eyeflow_dev
