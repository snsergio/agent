docker run \
    --name ${USER}_eyeflow_edge_dev \
    --gpus=all \
    --volume /data:/data \
    --volume /data/eyeflow:/opt/eyeflow \
    --volume ${PWD}:/home/container \
    -it eyeflow.azurecr.io/eyeflow_dev bash
