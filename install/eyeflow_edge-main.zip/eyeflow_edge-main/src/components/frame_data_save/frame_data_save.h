#pragma once

#include <string>

#include <nlohmann/json.hpp>
using json = nlohmann::json;

#include "frame_consumer.h"
// --------------------------------------------------------------------------------------------------------------------------------

namespace frame_data_save
{
    class Component: public FrameConsumer
    {
    public:
        Component(json parms);

        Component(Component&& other):
            FrameConsumer((FrameConsumer&&)other),
            m_out_filename(other.m_out_filename)
        {};

        ~Component();

        void start();
        int get_max_buffer_size();
        FrameResult process_frame(const Frame& input_frame);

        void stop();

        void start_save(double frame_time);
        void stop_save(double frame_time);

    private:
        std::string m_out_path;
        std::string m_out_filename;
        int m_saved_frames;
        bool m_save_stream;
        std::string m_window_name;

        std::string m_state_save;

        std::string m_data_filename;
        json m_frame_data;

        bool m_log_flag;
    };
} // namespace frame_data_save
// --------------------------------------------------------------------------------------------------------------------------------
