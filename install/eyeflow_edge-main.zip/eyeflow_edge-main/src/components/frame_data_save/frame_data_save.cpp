#include "frame_data_save.h"

#include <glog/logging.h>

#include <fstream>
#include <filesystem>
namespace fs = std::filesystem;

#include <edge_utils.h>

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------

namespace frame_data_save
{

Component::Component(json parms):
    FrameConsumer(parms)
{
    m_saved_frames = 0;
    m_save_stream = false;
    m_log_flag = false;
    m_out_path = parms["options"]["out_path"].get<string>();
};
// --------------------------------------------------------------------------------------------------------------------------------

Component::~Component()
{
    stop();
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::start()
{
    LOG(INFO) << "Frame data Save Started";
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::stop()
{
    if (m_save_stream)
        stop_save(common::get_systemtime_as_double());
}
// --------------------------------------------------------------------------------------------------------------------------------

int Component::get_max_buffer_size()
{
    return 0;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::start_save(double frame_time)
{
    if (m_save_stream)
        return;

    auto time = std::chrono::system_clock::now();
    std::ostringstream filename;
    std::time_t dateTime = std::chrono::system_clock::to_time_t(time);
    std::tm tm = *std::localtime(&dateTime);

    filename << m_out_path << "/" << m_window_name << "_" << std::put_time(&tm, "%Y%m%d_%H%M%S");
    m_data_filename = filename.str() + ".json";

    m_frame_data = json::array();
    m_save_stream = true;
    LOG(INFO) << "Start saving: " << m_window_name  << " - filename: " << m_out_filename  <<  " - init frames: " << m_saved_frames ;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::stop_save(double frame_time)
{
    if (!m_save_stream)
        return;

    try
    {
        fs::path dest_path(m_data_filename);
        std::ofstream fp_data(dest_path, std::ios_base::app);
        fp_data << m_frame_data << std::endl;
        fp_data.close();
    }
    catch(std::exception &e)
    {
        LOG(ERROR) << "Failed to save m_frame_data: " << e.what();
    }

    m_save_stream = false;
    LOG(INFO) << "Stop saving: " << m_window_name << " - filename: " << m_out_filename  <<  " - saved frames: " << m_saved_frames;
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult Component::process_frame(const Frame& input_frame)
{
    if (m_window_name.size() == 0)
    {
        if (input_frame.frame_data.contains("input_name"))
        {
            m_window_name = input_frame.frame_data["input_name"].get<string>() + "_" + m_component_id.to_string();
        }
        else
        {
            m_window_name = m_component_id.to_string();
        }

        return FrameResult::FRAME_OK;
    }

    m_log_flag = false;

    if (input_frame.frame_data["env_var"].contains("frame_data_save") && input_frame.frame_data["env_var"]["frame_data_save"].type() == json::value_t::string)
        m_state_save = input_frame.frame_data["env_var"]["frame_data_save"].get<string>();
    else if (input_frame.frame_data["env_var"].contains(m_window_name) && input_frame.frame_data["env_var"][m_window_name].contains("frame_data_save"))
        m_state_save = input_frame.frame_data["env_var"][m_window_name]["frame_data_save"].get<string>();

    bool cond_flow_test_ini = (!m_save_stream && input_frame.frame_data.contains("flow_test") && input_frame.frame_data["flow_test"].get<bool>() && input_frame.frame_data["test_playing"].get<bool>());
    bool cond_flow_test_end = (m_save_stream && input_frame.frame_data.contains("flow_test") && input_frame.frame_data["flow_test"].get<bool>() && !input_frame.frame_data["test_playing"].get<bool>());

    double frame_time = input_frame.frame_data["frame_time"].get<double>();

    if ((m_state_save == "start" && !m_save_stream) || cond_flow_test_ini)
    {
        m_saved_frames = 0;
        start_save(frame_time);
    }
    else if ((m_save_stream && m_state_save == "stop" ) || cond_flow_test_end)
    {
        m_frame_data.push_back(input_frame.frame_data);
        m_saved_frames++;
        stop_save(frame_time);
    }

    if (m_save_stream)
    {
        m_frame_data.push_back(input_frame.frame_data);
        m_saved_frames++;
    }

    return FrameResult::FRAME_OK;
}
// --------------------------------------------------------------------------------------------------------------------------------

} // namespace frame_data_save
