#include "video_test.h"

#include <fstream>
#include <thread>

#include <filesystem>
namespace fs = std::filesystem;

#include <env_var.h>

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------

namespace video_test
{

Component::~Component()
{
    if (m_grabbing)
        stop();

    m_video_cap.reset();
}
// --------------------------------------------------------------------------------------------------------------------------------

// Start Grabbing
void Component::start()
{
    if (m_grabbing)
        return;

    string video_file = m_parms["options"]["video_path"].get<string>() + "/" + m_parms["options"]["filename"].get<string>();

    if (!fs::exists(video_file))
        throw std::runtime_error("Cannot read the video file: " + video_file);

    m_video_cap.reset(new cv::VideoCapture(video_file));
    if (!m_video_cap->isOpened())
    {
        LOG(ERROR) << "Cannot read the video file: " << video_file;
        return;
    }

    LOG(INFO) << "Opened video file: " << video_file;

    m_has_frame_data = false;
    string frame_data_file = video_file.substr(0, video_file.size() - 4) + ".json";
    if (fs::exists(frame_data_file))
    {
        ifstream fp;
        fp.open(frame_data_file);
        if (!fp)
        {
            string err_msg = "Failed to open " + frame_data_file + " - " + strerror(errno);
            LOG(ERROR) << err_msg;
            throw system_error(errno, system_category(), "Failed to open " + frame_data_file);
        }

        m_frame_data = json::parse(fp);
        fp.close();

        LOG(INFO) << "Has frame_data file: " << frame_data_file;
        m_has_frame_data = true;
        m_frame_data_count = 0;

        if (m_frame_data[0].contains("frame_clock"))
        {
    		m_initial_time = m_frame_data[0]["frame_clock"].get<double>();
	    	m_start_time = common::get_steadytime_as_double();
        }
    }
    else
        LOG(WARNING) << "Video frame_data file not found: " << frame_data_file;

    m_camera_label = m_parms["options"]["label"].get<string>();
    m_camera_name = m_parms["options"]["camera_name"].get<string>();
    m_ini_frame = m_parms["options"].value("ini_frame", 0);
    m_end_frame = m_video_cap->get(cv::CAP_PROP_FRAME_COUNT);
    m_end_frame = min(m_parms["options"].value("end_frame", m_end_frame), m_end_frame);

    m_frame_seq = 0;
    while (m_frame_seq < m_ini_frame)
    {
        cv::Mat frame;
        if (!m_video_cap->read(frame))
        {
            LOG(ERROR) << "Cannot read the video file";
            return;
        }
        m_frame_seq++;
    }

    m_grabbing = true;
    m_start_process = std::chrono::steady_clock::now();
}
// --------------------------------------------------------------------------------------------------------------------------------

// Stop Grabbing
void Component::stop()
{
    if (m_grabbing)
    {
        m_video_cap->release();
        m_end_process = std::chrono::steady_clock::now();
        double time_taken = std::chrono::duration_cast<std::chrono::duration<double>>(m_end_process - m_start_process).count();

        m_grabbing = false;

        string video_file = m_parms["options"]["video_path"].get<string>() + "/" + m_parms["options"]["filename"].get<string>();
        LOG(INFO) << "Finished video file: " << video_file << \
            " - Frames: " << m_end_frame << \
            " - Time taken: " << std::fixed << time_taken << std::setprecision(4) << " seconds. FPS: " << (m_end_frame / time_taken);
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

bool Component::is_opened()
{
    if (m_video_cap)
        return m_video_cap->isOpened();
    else
        return false;
}
//---------------------------------------------------------------------------------------------------------------------------------

int Component::get_max_buffer_size()
{
    if (m_max_output_buffer > 0)
        return m_max_output_buffer;

    if (!m_grabbing)
    {
        start();
        // string err_msg("Need to start component first");
        // LOG(ERROR) << err_msg;
        // throw runtime_error(err_msg);
    }

    cv::Mat frame;
    if (!m_video_cap->read(frame))
    {
        LOG(ERROR) << "Cannot read the video file";
        return false;
    }

    unsigned char * frame_arr = frame.isContinuous()? frame.data: frame.clone().data;
    m_max_output_buffer = frame.total() * frame.channels();
    return m_max_output_buffer;
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult Component::grab_frame(Frame& output_frame)
{
    cv::Mat frame;

    if (m_has_frame_data && m_frame_data_count < (m_frame_data.size() - 1) && m_frame_data[m_frame_data_count + 1].contains("frame_clock"))
    {
		double now_time = common::get_steadytime_as_double() - m_start_time + m_initial_time;
        double frame_time = m_frame_data[m_frame_data_count + 1]["frame_clock"].get<double>();
		if (now_time < frame_time)
            std::this_thread::sleep_for(std::chrono::duration<double, std::micro>(frame_time - now_time));
    }
    else
    {
        std::this_thread::sleep_for(30ms);
    }

    if (!m_video_cap->read(frame))
    {
        if (m_video_cap->isOpened())
        {
            LOG(ERROR) << "Cannot read the video file";
            m_video_cap->release();
        }

        // output_frame.frame_data["frame_status"] = string("NOK");
        // return FrameResult::FRAME_EMPTY;
        frame = m_last_frame;
        m_frame_seq = m_end_frame;
    }
    else
        m_frame_seq++;


    unsigned char * frame_arr = frame.isContinuous()? frame.data: frame.clone().data;
    int frame_length = frame.total() * frame.channels();
    // LOG(INFO) << frame.cols << ", " << frame.rows << ", - type: " << frame.type() << " - FrameLen: " << frame_length;
    if (frame_length > output_frame.mem_buffer.buffer_size)
    {
        string err_msg = "Frame length > buffer_size - " + to_string(frame_length) + " > " + to_string(output_frame.mem_buffer.buffer_size);
        LOG(ERROR) << err_msg;
        m_max_output_buffer = frame_length;
        return FrameResult::FRAME_INVALID;
        // throw runtime_error(err_msg);
    }

    memcpy(output_frame.mem_buffer.buf_ptr, frame_arr, frame_length);

    output_frame.frame_data["frame_seq"] = m_frame_seq;
    output_frame.frame_data["frame_time"] = common::get_systemtime_as_double();

    if (m_has_frame_data)
    {
        output_frame.frame_data.update(m_frame_data[m_frame_data_count]);

        if (m_frame_data[m_frame_data_count].contains("frame_clock"))
        {
            common::EnvVar *env_var = common::EnvVar::get_instance();
            if (env_var != nullptr)
                env_var->update_variable("frame_clock", m_frame_data[m_frame_data_count]["frame_clock"].get<double>());
        }
        else
            output_frame.frame_data["frame_clock"] = common::get_steadytime_as_double();

        if (m_frame_data_count < (m_frame_data.size() - 1))
            m_frame_data_count++;
    }

    // output_frame.frame_data["frame_time"] = common::get_systemtime_as_double();

    output_frame.frame_data["input_label"] = m_camera_label;
    output_frame.frame_data["input_name"] = m_camera_name;
    output_frame.frame_data["frame_status"] = string("OK");
    output_frame.frame_data["frame_width"] = frame.cols;
    output_frame.frame_data["frame_height"] = frame.rows;
    output_frame.frame_data["frame_mat_type"] = frame.type();
    output_frame.frame_data["end_frame"] = m_end_frame;
    output_frame.frame_data["input_frame_size"] = json::array({frame.cols, frame.rows});

    if (m_grabbing && m_frame_seq < m_end_frame)
    {
        output_frame.frame_data["test_playing"] = true;
    }
    else
    {
        output_frame.frame_data["test_playing"] = false;
        stop();
    }

    m_last_frame = frame;

    return FrameResult::FRAME_OK;
}
// --------------------------------------------------------------------------------------------------------------------------------

} // namespace video_test
