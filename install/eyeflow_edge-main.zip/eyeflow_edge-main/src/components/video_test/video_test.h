#pragma once

#include <chrono>

#include <opencv2/opencv.hpp>

#include "frame_streamer.h"
// --------------------------------------------------------------------------------------------------------------------------------

namespace video_test
{

class Component: public FrameStreamer
{
public:
    Component(json parms):
        FrameStreamer(parms),
        m_grabbing(false),
        m_max_output_buffer(0)
    {};
    ~Component();

    // Start Grabbing
    void start();
    FrameResult grab_frame(Frame& output_frame);
    int get_max_buffer_size();

    // Stop Grabbing
    void stop();
    void restart(){};

    bool is_opened();

private:
    std::string m_camera_label;
    std::string m_camera_name;

	double m_initial_time;
	double m_start_time;
    cv::Mat m_last_frame;
    std::unique_ptr<cv::VideoCapture> m_video_cap;
    json m_frame_data;
    bool m_has_frame_data;
    int m_frame_data_count;

    bool m_grabbing;
    int m_max_output_buffer;
    int m_frame_seq;

    std::chrono::steady_clock::time_point m_start_process;
    std::chrono::steady_clock::time_point m_end_process;

    int m_ini_frame;
    int m_end_frame;
};

} // namespace video_test