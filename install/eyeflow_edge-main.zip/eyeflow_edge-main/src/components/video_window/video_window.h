#pragma once

#include <string>
#include <vector>
#include <thread>

#include <opencv2/opencv.hpp>
#include <glog/logging.h>

#include <nlohmann/json.hpp>
using json = nlohmann::json;

#include <edge_utils.h>
#include "frame_consumer.h"
// --------------------------------------------------------------------------------------------------------------------------------

namespace video_window
{
    class Component: public FrameConsumer
    {
    public:
        Component(json parms);

        // Component(Component&& other):
        //     FrameConsumer((FrameConsumer&&)other),
        //     m_window_name(other.m_window_name),
        //     m_input_list(other.m_input_list),
        //     m_max_width(other.m_max_width),
        //     m_max_height(other.m_max_height)
        // {};

        ~Component();

        void start();
        void stop();

        FrameResult process_frame(const Frame& input_frame);

    private:
        int m_max_width;
        int m_max_height;
        std::string m_window_name;
        std::vector<std::string> m_input_list;
        std::vector<cv::Size> m_input_size_list;
        std::vector<cv::Size> m_output_size_list;
        std::vector<cv::Mat> m_frames_list;
        bool m_started;

        void compute_output_size();
        void show_window();
    };
} // namespace video_window
// --------------------------------------------------------------------------------------------------------------------------------
