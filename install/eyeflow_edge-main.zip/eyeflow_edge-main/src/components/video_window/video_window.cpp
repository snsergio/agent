#include "video_window.h"

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------

namespace video_window
{


Component::Component(json parms):
    FrameConsumer(parms)
{
    // bsoncxx::oid()
    m_window_name = parms["options"]["label"].get<string>();
    m_max_width = parms["options"]["m_max_width"].get<int>();
    m_max_height = parms["options"]["m_max_height"].get<int>();
    m_started = false;
};
// --------------------------------------------------------------------------------------------------------------------------------

Component::~Component()
{
    stop();
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::start()
{
    cv::namedWindow(m_window_name);
    m_started = true;
    LOG(INFO) << "Video Window Started: " << m_window_name;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::compute_output_size()
{
    double total_width = 0;
    double total_height = 0;
    for (auto size : m_input_size_list)
    {
        if (size.height > total_height)
            total_height = size.height;

        total_width += size.width;
    }

    double scale = min(m_max_width / total_width, m_max_height / total_height);

    m_output_size_list.clear();
    int idx = 0;
    for (auto size : m_input_size_list)
    {
        m_output_size_list.push_back(cv::Size((int)(size.width * scale), (int)(size.height * scale)));
        cv::resize(m_frames_list[idx], m_frames_list[idx], m_output_size_list[idx]);
        idx++;
    }

}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::show_window()
{
    double total_width = 0;
    double total_height = 0;
    for (auto size : m_output_size_list)
    {
        if (size.height > total_height)
            total_height = size.height;

        total_width += size.width;
    }

    cv::Mat output_image(total_height, total_width, CV_8UC3);
    int pos_x = 0;
    int index = 0;
    cv::Mat dest_roi;
    for (auto frame : m_frames_list)
    {
        std::string display_text;
        if (index < m_input_list.size() ) {
            display_text = m_input_list[index];
        }  
        display_text = index < m_input_list.size() ? m_input_list[index]  : "cam";
        dest_roi = output_image(cv::Range(0, frame.rows), cv::Range(pos_x, pos_x + frame.cols));
        cv::putText(dest_roi, display_text, cv::Point(11, (12)), cv::FONT_HERSHEY_DUPLEX, 2.0, CV_RGB(0, 0, 0), 2);
        frame.copyTo(dest_roi);
        pos_x += frame.cols;
        index++;
    }

    cv::imshow(m_window_name, output_image);
    cv::waitKey(1);

}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult Component::process_frame(const Frame& input_frame)
{
    int frame_width = input_frame.frame_data.at("frame_width").get<int>();
    int frame_height = input_frame.frame_data.at("frame_height").get<int>();
    cv::Mat frame(cv::Size(frame_width, frame_height), input_frame.frame_data.at("frame_mat_type").get<int>(), input_frame.mem_buffer.buf_ptr);

    int index = -1;
    if (input_frame.frame_data.contains("input_label"))
    {
        auto it = find(m_input_list.begin(), m_input_list.end(), input_frame.frame_data["input_label"].get<string>());
        if (it == m_input_list.end())
        {
            m_input_list.push_back(input_frame.frame_data["input_label"].get<string>());
            m_input_size_list.push_back(cv::Size(frame_width, frame_height));

            cv::Mat output_frame(cv::Size(frame_width, frame_height), CV_8UC3);
            frame.convertTo(output_frame, CV_8UC3);
            m_frames_list.push_back(output_frame);

            compute_output_size();
            index = m_input_list.size() - 1;
        }
        else
        {
            index = it - m_input_list.begin();
            cv::Mat output_frame(cv::Size(frame_width, frame_height), CV_8UC3);
            frame.convertTo(output_frame, CV_8UC3);
            cv::resize(output_frame, m_frames_list[index], m_output_size_list[index]);
        }
    }

    show_window();

    // double frame_time = input_frame.frame_data.at("frame_time").get<double>();

    return FrameResult::FRAME_OK;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::stop()
{
    if (m_started)
    {
        cv::destroyWindow(m_window_name);
        cv::waitKey(1);
    }

    m_started = false;
}
// --------------------------------------------------------------------------------------------------------------------------------

} // namespace video_window
// --------------------------------------------------------------------------------------------------------------------------------
