#include "video_save.h"

#include <glog/logging.h>

#include <fstream>
#include <filesystem>
namespace fs = std::filesystem;

#include <edge_utils.h>

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------
namespace video_save
{

Component::Component(json parms):
    FrameConsumer(parms)
{
    m_out_size = cv::Size(parms["options"]["out_width"].get<int>(), parms["options"]["out_height"].get<int>());
    m_frame_rate = parms["options"]["frame_rate"].get<int>();
    m_skip_frames = parms["options"]["skip_frames"].get<int>();
    m_skiped_frames = 0;
    m_saved_frames = 0;
    m_save_stream = false;
    m_save_change_state = 0;
    m_log_flag = false;
    m_out_path = parms["options"]["out_path"].get<string>();
    fs::create_directory(m_out_path);
    m_keyboard_mode = false;
};
// --------------------------------------------------------------------------------------------------------------------------------

Component::~Component()
{
    stop();
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::start()
{
    LOG(INFO) << "Video Save Started";

}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::stop()
{
    if (m_save_stream)
        stop_save(common::get_systemtime_as_double());
}
// --------------------------------------------------------------------------------------------------------------------------------

int Component::get_max_buffer_size()
{
    return 0;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::start_save(double frame_time)
{
    if (m_save_stream)
        return;

    auto time = std::chrono::system_clock::now();
    std::ostringstream filename;
    std::time_t dateTime = std::chrono::system_clock::to_time_t(time);
    std::tm tm = *std::localtime(&dateTime);

    filename << m_out_path << "/" << m_input_camera << "_" << m_input_component_id << "_" << std::put_time(&tm, "%Y%m%d_%H%M%S");
    if (m_part_id != "")
        filename << "_" << m_part_id;

    m_out_filename = filename.str() + ".avi";
    // m_out_filename = filename.str() + ".mp4";
    m_data_filename = filename.str() + ".json";
    m_frame_data = json::array();

    m_video_writer.open(m_out_filename, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'), m_frame_rate, m_out_size);
    // m_video_writer.open(m_out_filename, cv::VideoWriter::fourcc('m', 'p', '4', 'v'), m_frame_rate, m_out_size);

    m_save_stream = true;
    m_save_change_state = frame_time;
    m_saved_frames = 0;

    LOG(INFO) << "Start saving: " << m_input_camera  << " filename: " << m_out_filename  <<  " init frames: " << m_saved_frames;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::stop_save(double frame_time)
{
    if (!m_save_stream)
        return;

    try
    {
        m_video_writer.release();
        if (m_saved_frames < 0)
        {
            fs::path filename(m_out_filename);
            if (fs::is_regular_file(filename))
                fs::remove(filename);
            LOG(INFO) << "Stop saving Remove file total  frames < 30: " << m_input_camera << " id: " << m_part_id  <<  " filename: " << m_out_filename  <<  " saved frames: " << m_saved_frames <<  "size: " << std::to_string(std::filesystem::file_size(m_out_filename )/1024) << "K";
        }

        fs::path dest_path(m_data_filename);
        std::ofstream fp_data(dest_path);
        fp_data << m_frame_data << std::endl;
        LOG(INFO) << "Save frame_data file: " << m_data_filename;
    }
    catch(const std::exception& e)
    {
        LOG(ERROR) << "Fail stopping save: " << e.what();
    }

    m_save_stream = false;
    m_save_change_state = frame_time;
    LOG(INFO) << "Stop saving: " << m_input_camera << " Part id: " << m_part_id  <<  " filename: " << m_out_filename  <<  " saved frames: " << m_saved_frames;
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult Component::process_frame(const Frame& input_frame)
{
    if (m_input_camera.size() == 0)
    {
        if (input_frame.frame_data.contains("input_name"))
        {
            m_input_camera = input_frame.frame_data["input_name"].get<string>();
        }
        else
        {
            m_input_camera = input_frame.frame_data["component_output"].get<string>();
        }
    }

    if (m_input_component_id.size() == 0)
        m_input_component_id = input_frame.frame_data["component_output"].get<string>();

    if (input_frame.frame_data["env_var"].contains("inspection_manager") &&
        input_frame.frame_data["env_var"]["inspection_manager"].contains("conveyor_status") &&
        (input_frame.frame_data["env_var"]["inspection_manager"]["conveyor_status"]["conveyor_status"].get<string>() == "STOP")
    )
    {
        if (!m_log_flag)
        {
            LOG(INFO) << "Video save paused: " << m_input_camera  << " filename: " << m_out_filename;
            m_log_flag = true;
        }

        m_surface_end_timeout = time(NULL);

        return FrameResult::FRAME_OK;
    }

    m_log_flag = false;

    if(!m_keyboard_mode)
    {
        if (input_frame.frame_data["env_var"].contains("states") && input_frame.frame_data["env_var"]["states"].contains(m_input_camera))
            m_state_save = input_frame.frame_data["env_var"]["states"][m_input_camera].value("action", "");
        else if (input_frame.frame_data["env_var"].contains("video_save") && input_frame.frame_data["env_var"]["video_save"].type() == json::value_t::string)
            m_state_save = input_frame.frame_data["env_var"]["video_save"].get<string>();
        else if (input_frame.frame_data["env_var"].contains(m_input_camera) && input_frame.frame_data["env_var"][m_input_camera].contains("video_save"))
            m_state_save = input_frame.frame_data["env_var"][m_input_camera]["video_save"].get<string>();
    }

    bool cond_flow_test_ini = (!m_save_stream && input_frame.frame_data.contains("flow_test") && input_frame.frame_data["flow_test"].get<bool>() && input_frame.frame_data["test_playing"].get<bool>());
    bool cond_flow_test_end = (m_save_stream && input_frame.frame_data.contains("flow_test") && input_frame.frame_data["flow_test"].get<bool>() && !input_frame.frame_data["test_playing"].get<bool>());

    if(cond_flow_test_ini)
    {
        LOG(INFO) << "Condition flow_test_ini=true";
        m_state_save = "start";
    }
    if(cond_flow_test_end)
    {
        LOG(INFO) << "Condition flow_test_end=true";
        m_state_save = "stop";
    }

    bool cond_keyboard_start = (input_frame.frame_data["env_var"].contains("video_save_keyboard") && input_frame.frame_data["env_var"]["video_save_keyboard"] == true);
    bool cond_keyboard_end = (input_frame.frame_data["env_var"].contains("video_save_keyboard") && input_frame.frame_data["env_var"]["video_save_keyboard"] == false);

    if(cond_keyboard_start)
    {
        if(!m_save_stream)
        {
            m_keyboard_mode = true;
            LOG(INFO) << "Press keyboard start";
            m_state_save = "start";
        }
    }
    else if(cond_keyboard_end && m_keyboard_mode)
    {
        if(m_save_stream)
        {
            m_keyboard_mode = false;
            LOG(INFO) << "Press keyboard stop";
            m_state_save = "stop";
        }

        m_keyboard_mode = false;
    }

    double frame_time = input_frame.frame_data["frame_time"].get<double>();

    if(m_state_save == "start" && !m_save_stream)
    {
        if (input_frame.frame_data["env_var"].contains("states") && input_frame.frame_data["env_var"]["states"].contains(m_input_camera))
            m_part_id = input_frame.frame_data["env_var"]["states"][m_input_camera].value("car_id", "");

		int frame_height = input_frame.frame_data["frame_height"].get<int>();
		int frame_width = input_frame.frame_data["frame_width"].get<int>();
        m_out_size = cv::Size(frame_width, frame_height);
        m_saved_frames = 0;
        start_save(frame_time);
        // LOG(INFO) << "Start Save " << m_input_camera << " filename: " << m_out_filename;//  << input_frame.frame_data.dump();
    }
    else if(m_save_stream && m_state_save == "stop" )
    {
        cv::Mat frame(cv::Size(input_frame.frame_data["frame_width"].get<int>(), input_frame.frame_data["frame_height"].get<int>()), input_frame.frame_data["frame_mat_type"].get<int>(), input_frame.mem_buffer.buf_ptr);
        cv::Mat frame_out(m_out_size, input_frame.frame_data["frame_mat_type"].get<int>());
        cv::resize(frame, frame_out, m_out_size, cv::INTER_AREA);
        m_video_writer.write(frame_out);
        m_frame_data.push_back(input_frame.frame_data);
        m_saved_frames++;

        stop_save(frame_time);

        // LOG(INFO) << "Stop Save " <<  m_input_camera << " filename: " << m_out_filename;
            // <<  " frame_data: " << input_frame.frame_data.dump();
    }

    if (m_save_stream)
    {
        cv::Mat frame(cv::Size(input_frame.frame_data["frame_width"].get<int>(), input_frame.frame_data["frame_height"].get<int>()), input_frame.frame_data["frame_mat_type"].get<int>(), input_frame.mem_buffer.buf_ptr);
        cv::Mat frame_out(m_out_size, input_frame.frame_data["frame_mat_type"].get<int>());
        cv::resize(frame, frame_out, m_out_size, cv::INTER_AREA);

        m_video_writer.write(frame_out);
        m_frame_data.push_back(input_frame.frame_data);

        m_skiped_frames = 0;
        m_saved_frames++;
    }

    return FrameResult::FRAME_OK;
}
// --------------------------------------------------------------------------------------------------------------------------------

} // namespace video_save


        // int conveyour = input_frame.frame_data["env_var"]["states"][m_input_camera].value("sensor_conveyor", -1);
        // int started = input_frame.frame_data["env_var"]["states"][m_input_camera].value("sensor_started", -1);
        // std::string model = input_frame.frame_data["env_var"]["states"][m_input_camera].value("car_model", "");

        // if(started > 0 && conveyour > 0 && cond_save_conveyor)
        // {

        //     cv::Scalar cor = CV_RGB(134, 18, 134);
        //     std::stringstream ss;
        //     ss <<  "conveyor_started: "  <<  std::to_string(started) <<   " conveyour: " << std::to_string(conveyour)  <<  " model: " << model;
        //     int y = 50;

        //     std::string txt = "conveyor_started: "  + std::to_string(started);

        //     cv::putText(frame_out, //target image
        //         txt, //text
        //         cv::Point(20, y), //top-left position
        //         cv::FONT_HERSHEY_DUPLEX,
        //         2.0,
        //         cor, //font color
        //         2);

        //     y+= 80;

        //    txt = "conveyor: "  + std::to_string(conveyour) ;
        //      cv::putText(frame_out, //target image
        //         txt, //text
        //         cv::Point(20, y), //top-left position
        //         cv::FONT_HERSHEY_DUPLEX,
        //         2.0,
        //        cor, //font color
        //         2);

        //     y+= 80;

        //     txt = "r: "  + std::to_string(conveyour - started) ;
        //      cv::putText(frame_out, //target image
        //         txt, //text
        //         cv::Point(20, y), //top-left position
        //         cv::FONT_HERSHEY_DUPLEX,
        //         2.0,
        //        cor, //font color
        //         2);

        //     y+= 80;

        //     txt = "model "  + model;
        //      cv::putText(frame_out, //target image
        //         txt, //text
        //         cv::Point(20, y), //top-left position
        //         cv::FONT_HERSHEY_DUPLEX,
        //         2.0,
        //         cor, //font color
        //         2);
        // }
