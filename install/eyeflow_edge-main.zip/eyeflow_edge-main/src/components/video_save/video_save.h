#pragma once

#include <string>

#include <opencv2/opencv.hpp>

#include <nlohmann/json.hpp>
using json = nlohmann::json;

#include "frame_consumer.h"
// --------------------------------------------------------------------------------------------------------------------------------

namespace video_save
{
class Component: public FrameConsumer
{
public:
    Component(json parms);

    Component(Component&& other):
        FrameConsumer((FrameConsumer&&)other),
        m_out_size(std::move(other.m_out_size)),
        m_frame_rate(other.m_frame_rate),
        m_out_filename(other.m_out_filename),
        m_skip_frames(other.m_skip_frames),
        m_skiped_frames(other.m_skiped_frames)
    {};

    ~Component();

    void start();
    int get_max_buffer_size();
    FrameResult process_frame(const Frame& input_frame);

    void stop();

    void start_save(double frame_time);
    void stop_save(double frame_time);

private:
    cv::Size m_out_size;
    int m_frame_rate;
    std::string m_out_path;
    std::string m_out_filename;
    int m_skip_frames;
    int m_skiped_frames;
    int m_saved_frames;
    bool m_save_stream;
    double m_save_change_state;
    std::string m_input_camera;
    std::string m_input_component_id;
    time_t m_surface_end_timeout;
    std::string m_part_id;

    bool m_keyboard_mode;
    std::string m_state_save;

    std::string m_data_filename;
    json m_frame_data;

    bool m_log_flag;

    cv::VideoWriter m_video_writer;
};

} // namespace video_save
// --------------------------------------------------------------------------------------------------------------------------------
