#include "image_test.h"

#include <fstream>
#include <filesystem>
namespace fs = std::filesystem;

#include <opencv2/opencv.hpp>
// --------------------------------------------------------------------------------------------------------------------------------

namespace image_test
{

Component::Component(json parms):
    FrameStreamer(parms),
    m_grabbing(false),
    m_max_output_buffer(0)
{
    start();
};
// --------------------------------------------------------------------------------------------------------------------------------

Component::~Component()
{
    if (m_grabbing)
        stop();
}
// --------------------------------------------------------------------------------------------------------------------------------

// Start Grabbing
void Component::start()
{
    if (m_grabbing)
        return;

    std::string images_path = m_parms["options"]["image_path"].get<std::string>();

    for (const auto& entry : fs::directory_iterator(images_path))
    {
        if (entry.is_regular_file() && entry.path().has_extension() && entry.path().extension() == ".jpg")
        {
            cv::Mat img = cv::imread(entry.path().string());
            size_t size_bytes = img.total() * img.elemSize();
            if (size_bytes > m_max_output_buffer)
                m_max_output_buffer = size_bytes;

            json img_file = {
                {"file_name", entry.path().string()}
            };

            std::string data_file = entry.path().parent_path().append(entry.path().stem().string() + "_data.json");
            if (fs::exists(data_file))
            {
                std::ifstream fp;
                fp.open(data_file);
                if (!fp)
                {
                    std::string err_msg = "Failed to open " + data_file + " - " + strerror(errno);
                    LOG(ERROR) << err_msg;
                    throw std::system_error(errno, std::system_category(), "Failed to open " + data_file);
                }

                img_file["file_data"] = json::parse(fp);
                fp.close();
            }

            m_image_list.push_back(img_file);
        }

        // if (m_image_list.size() >= 10)
        //     break;
    }

    LOG(INFO) << "Images files: " << m_image_list.size();

    m_camera_label = m_parms["options"]["label"].get<std::string>();
    m_camera_name = m_parms["options"]["camera_name"].get<std::string>();

    m_frame_seq = 0;

    m_grabbing = true;
    m_start_process = std::chrono::steady_clock::now();
}
// --------------------------------------------------------------------------------------------------------------------------------

// Stop Grabbing
void Component::stop()
{
    if (m_grabbing)
    {
        m_end_process = std::chrono::steady_clock::now();
        double time_taken = std::chrono::duration_cast<std::chrono::duration<double>>(m_end_process - m_start_process).count();

        m_grabbing = false;

        LOG(INFO) << "Finished streaming images" << \
            " - Frames: " << m_frame_seq << \
            " - Time taken: " << std::fixed << time_taken << std::setprecision(4) << " seconds. FPS: " << (m_frame_seq / time_taken);
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

bool Component::is_opened()
{
    if (m_frame_seq < m_image_list.size())
        return true;
    else
        return false;
}
//---------------------------------------------------------------------------------------------------------------------------------

int Component::get_max_buffer_size()
{
    return m_max_output_buffer;
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult Component::grab_frame(Frame& output_frame)
{
    json image_file = m_image_list[m_frame_seq];
    cv::Mat frame;

    if (!m_grabbing)
    {
        frame = m_last_frame;
    }
    else
    {
        frame = cv::imread(image_file["file_name"].get<std::string>());
    }

    unsigned char * frame_arr = frame.isContinuous()? frame.data: frame.clone().data;
    int frame_length = frame.total() * frame.elemSize();
    memcpy(output_frame.mem_buffer.buf_ptr, frame_arr, frame_length);

    output_frame.frame_data["frame_seq"] = m_frame_seq;
    output_frame.frame_data["frame_time"] = common::get_systemtime_as_double();

    output_frame.frame_data["image_file_name"] = image_file["file_name"].get<std::string>();
    if (image_file.contains("file_data"))
    {
        output_frame.frame_data["image_annotations"] = image_file["file_data"];
    }

    // output_frame.frame_data["frame_time"] = common::get_systemtime_as_double();

    output_frame.frame_data["input_label"] = m_camera_label;
    output_frame.frame_data["input_name"] = m_camera_name;
    output_frame.frame_data["frame_status"] = std::string("OK");
    output_frame.frame_data["frame_width"] = frame.cols;
    output_frame.frame_data["frame_height"] = frame.rows;
    output_frame.frame_data["frame_mat_type"] = frame.type();
    output_frame.frame_data["end_frame"] = m_image_list.size();
    output_frame.frame_data["input_frame_size"] = json::array({frame.cols, frame.rows});

    if (m_grabbing)
        output_frame.frame_data["test_playing"] = true;
    else
        output_frame.frame_data["test_playing"] = false;

    m_last_frame = frame;

    m_frame_seq++;
    if (m_frame_seq >= m_image_list.size() && m_grabbing)
    {
        m_frame_seq = m_image_list.size() - 1;
        stop();
    }

    return FrameResult::FRAME_OK;
}
// --------------------------------------------------------------------------------------------------------------------------------

} // namespace image_test
