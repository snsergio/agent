#pragma once

#include <chrono>

#include "frame_streamer.h"
// --------------------------------------------------------------------------------------------------------------------------------

namespace image_test
{

class Component: public FrameStreamer
{
public:
    Component(json parms);
    ~Component();

    // Start Grabbing
    void start();
    FrameResult grab_frame(Frame& output_frame);
    int get_max_buffer_size();

    // Stop Grabbing
    void stop();
    void restart(){};

    bool is_opened();

private:
    std::string m_camera_label;
    std::string m_camera_name;

    std::vector<json> m_image_list;

    cv::Mat m_last_frame;

    bool m_grabbing;
    int m_max_output_buffer;
    int m_frame_seq;

    std::chrono::steady_clock::time_point m_start_process;
    std::chrono::steady_clock::time_point m_end_process;
};

} // namespace image_test
