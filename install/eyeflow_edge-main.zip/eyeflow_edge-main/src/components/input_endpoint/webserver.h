#pragma once

#include <chrono>
#include <thread>
#include <mutex>
#include <string.h>
#include <string>
#include <opencv2/opencv.hpp>

#define CPPHTTPLIB_SEND_FLAGS MSG_NOSIGNAL //Required to avoid "Broken Pipe" error in httplib.h
#include <httplib.h>
#include <base64.h>
#include <nlohmann/json.hpp>
using json = nlohmann::json;
// --------------------------------------------------------------------------------------------------------------------------------

namespace input_endpoint
{
    struct RequestData
    {
        RequestData(){}
        ~RequestData(){}

        std::string image_type;
        cv::Mat image;
        // httplib::Response res
    };

    class WebServer
    {
    public:
        WebServer(json parms);
        ~WebServer();

        void start();
        void stop();
        void restart();

        std::shared_ptr<RequestData> on_image_recv();

    private:
        std::string m_listen_host;
        int m_listen_port;

        bool m_ws_running = false;

        httplib::Server m_svr;
        std::thread m_thd_server;
        std::mutex m_mutex;
        std::vector<std::shared_ptr<RequestData>> m_request_data_buffer;

        void send_json(httplib::Response& res, const json &message, const int status);
        void run_server();
    };
} // namespace input_endpoint
