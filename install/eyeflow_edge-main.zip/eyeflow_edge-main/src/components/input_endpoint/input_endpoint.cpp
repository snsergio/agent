#include "input_endpoint.h"

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------

namespace input_endpoint
{
Component::Component(json parms) : FrameStreamer(parms)
{
    m_max_output_buffer = 0;

    m_parms = parms["options"];
    m_camera_label = parms["options"]["label"].get<string>();
    m_camera_name = parms["options"]["camera_name"].get<string>();
    m_max_output_buffer = parms["options"].value("max_output_buffer", 4000*3000*3); // 12MP
    m_grabbing = false;
    m_frame_seq = 0;

    m_web_server = std::make_unique<WebServer>(m_parms);
    start();
}
// --------------------------------------------------------------------------------------------------------------------------------

Component::~Component()
{
    stop();
}
// --------------------------------------------------------------------------------------------------------------------------------

// Start Grabbing
void Component::start()
{
    if (m_grabbing)
        return;

    LOG(INFO) << "Input Endpoint Started";
    m_web_server->start();
    m_grabbing = true;
}
// --------------------------------------------------------------------------------------------------------------------------------

// Stop Grabbing
void Component::stop()
{
    if (!m_grabbing)
        return;

    m_grabbing = false;
    m_web_server->stop();
    LOG(INFO) << "Input Endpoint Stopped";
}
// --------------------------------------------------------------------------------------------------------------------------------

void Component::restart() {
    stop();
    start();
}
// --------------------------------------------------------------------------------------------------------------------------------

int Component::get_max_buffer_size()
{
    return m_max_output_buffer;
}
//--------------------------------------------------------------------------------------------------------------------------------

FrameResult Component::grab_frame(Frame &output_frame)
{    
    LOG(INFO) << "grab_frame -> Waiting for image request";
    std::shared_ptr<RequestData> request_data = m_web_server->on_image_recv();
    LOG(INFO) << "grab_frame -> Image recv";
    cv::Mat frame = request_data->image;
    cv::Size size = frame.size();
    unsigned char * frame_arr = frame.isContinuous()? frame.data: frame.clone().data;
    int frame_length = frame.total() * frame.channels();
    memcpy(output_frame.mem_buffer.buf_ptr, frame_arr, frame_length);

    output_frame.frame_data["input_label"] = m_camera_label;
    output_frame.frame_data["input_name"] = m_camera_name;
    output_frame.frame_data["frame_status"] = string("OK");
    output_frame.frame_data["frame_width"] = size.width;
    output_frame.frame_data["frame_height"] = size.height;
    output_frame.frame_data["frame_mat_type"] = CV_8UC3;
    output_frame.frame_data["frame_seq"] = m_frame_seq;
    output_frame.frame_data["frame_time"] = common::get_systemtime_as_double();
    output_frame.frame_data["frame_clock"] = common::get_steadytime_as_double();
    output_frame.frame_data["input_frame_size"] = json::array({size.width, size.height});

    m_frame_seq++;
    return FrameResult::FRAME_OK;
}
// --------------------------------------------------------------------------------------------------------------------------------
} // namespace input_endpoint
