import time
import random
import base64
import requests
import datetime


import cv2
import numpy as np


def test_endpoint(endpoint_host, iterations_num, sleep_time=1, show_image=True):

    for i in range(iterations_num):
        cv2.destroyAllWindows()
        height = random.randint(200, 400)
        width = random.randint(200, 400)
        blank_image = np.zeros((height, width, 3), np.uint8)
        cv2.putText(blank_image, f"Iteration {i}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

        data_payload = {
            "image_type": "jpg",
            "base64": base64.b64encode(cv2.imencode('.jpg', blank_image)[1]).decode('utf-8'),
            "time": datetime.datetime.now().isoformat()
        }

        response = requests.post(endpoint_host, json=data_payload)
        print(response.json())

        if show_image:
            cv2.imshow('Blank image', blank_image)
            cv2.waitKey(sleep_time*1000)
        else:
            if i != iterations_num - 1:
                time.sleep(sleep_time)


if __name__ == "__main__":
    test_endpoint(
        "http://localhost:8001",
        1,
        sleep_time=5,
        show_image=False
        )
