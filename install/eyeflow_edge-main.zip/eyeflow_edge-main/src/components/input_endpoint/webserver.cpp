#include "input_endpoint.h"

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------

namespace input_endpoint
{
WebServer::WebServer(json parms)
{
    m_listen_host = parms.value("listen_host", "0.0.0.0");
    m_listen_port = parms.value("listen_port", 8001);
    start();
}
// --------------------------------------------------------------------------------------------------------------------------------

WebServer::~WebServer()
{
    if (!m_ws_running)
        return;

    LOG(INFO) << "Input Endpoint WebServer Stopped";
    m_svr.stop();
    if (m_thd_server.joinable())
    {
        m_thd_server.join();
    }
    m_ws_running = false;
}
// --------------------------------------------------------------------------------------------------------------------------------

// Start Grabbing
void WebServer::start()
{
    LOG(INFO) << "Starting Input Endpoint Web Server. " << "Listen Host: " << m_listen_host << " Listen Port: " << m_listen_port;
    m_thd_server = thread(&WebServer::run_server, this);
    m_thd_server.detach();
    m_ws_running = true;
} 
// --------------------------------------------------------------------------------------------------------------------------------

// Stop Grabbing
void WebServer::stop()
{

    LOG(INFO) << "Input Endpoint WebServer Stopped";
    m_svr.stop();
    m_thd_server.join();
}
// --------------------------------------------------------------------------------------------------------------------------------

void WebServer::restart() {
    stop();
    start();
}

std::shared_ptr<RequestData> WebServer::on_image_recv()
{
    while (true)
    {
        try
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_request_data_buffer.size() > 0)
            {
                auto request_data = m_request_data_buffer.front();
                m_request_data_buffer.erase(m_request_data_buffer.begin());
                return request_data;
            }
        }
        catch (std::exception &excpt)
        {
            LOG(ERROR) << "Fail on_image_recv: " << excpt.what();
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

void WebServer::send_json(httplib::Response& res, const json &data, const int status)
{
    res.status = status;
    res.set_header("Access-Control-Allow-Origin", "*");
    res.set_content(data.dump(), "application/json");
}
// --------------------------------------------------------------------------------------------------------------------------------

void WebServer::run_server()
{
    m_svr.Get("/", [&](const httplib::Request& req, httplib::Response& res)
    {
        try
        {
            json json_message = {
                {"ok", true},
            };

            send_json(res, json_message, 200);
        }
        catch (std::exception &excpt)
        {
            string err_message = excpt.what();

            LOG(ERROR) << "Fail receiving data: " << err_message;

            json json_message = {
                {"ok", false},
                {"err_message", err_message}
            };
            send_json(res, json_message, 500);
        }
    });

    m_svr.Post("/", [&](const httplib::Request &req, httplib::Response &res)
    {
        try
        {
            LOG(INFO) << "Post /";
            json body = json::parse(req.body);
            json json_message = {};

            if (!body.contains("image_type"))
            {
                json_message["ok"] = false;
                json_message["err_message"] = "Missing image_type";
                send_json(res, json_message, 400);
                return;
            }
            else if (!body.contains("base64"))
            {
                json_message["ok"] = false;
                json_message["err_message"] = "Missing base64";
                send_json(res, json_message, 400);
                return;
            }

            std::string image_type = body.value("image_type", "jpg");
            if (image_type != "jpg" && image_type != "png")
            {
                json_message["ok"] = false;
                json_message["err_message"] = "Invalid image_type. Only jpg and png are supported";
                send_json(res, json_message, 400);
                return;
            }

            RequestData request_data;
            request_data.image_type = image_type;
            auto decoded_image = base64_decode(body["base64"].get<std::string>());
            std::vector<uchar> data(decoded_image.begin(), decoded_image.end());
            if (image_type == "jpg")
            {
                request_data.image = cv::imdecode(data, cv::IMREAD_COLOR);
            }
            else if (image_type == "png")
            {
                request_data.image = cv::imdecode(data, cv::IMREAD_UNCHANGED);
            }

            if (request_data.image.empty())
            {
                json_message["ok"] = false;
                json_message["err_message"] = "Fail to decode image";
                send_json(res, json_message, 400);
                return;
            }

            {
                std::lock_guard<std::mutex> lock(m_mutex);
                m_request_data_buffer.push_back(std::make_shared<RequestData>(request_data));
            }

            json_message["ok"] = true;
            send_json(res, json_message, 200);
            LOG(INFO) << "Post / - OK";
        }
        catch (std::exception &excpt)
        {
            string err_message = excpt.what();

            LOG(ERROR) << "Fail receiving data: " << err_message;

            json json_message = {
                {"ok", false},
                {"err_message", err_message}
            };
            send_json(res, json_message, 500);
            LOG(INFO) << "Post / - FAIL";
        }
    });

    m_svr.Get(R"(/.*)",[&](const httplib::Request& req, httplib::Response& res)
    {
        LOG(INFO) << "Page Not Found";

        res.set_header("Access-Control-Allow-Origin", "*");
        json json_message = {
            {"ok", false},
            {"err_message", "Page Not Found"}
        };
        send_json(res, json_message, 404);
    });

    m_svr.listen(m_listen_host.c_str(), m_listen_port);
}
// --------------------------------------------------------------------------------------------------------------------------------
} // namespace input_endpoint
