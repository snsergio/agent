#pragma once

#include <string.h>
#include <string>
#include <opencv2/opencv.hpp>

#include "frame_streamer.h"
#include "webserver.h"
// --------------------------------------------------------------------------------------------------------------------------------

namespace input_endpoint
{
    class Component : public FrameStreamer
    {
    public:
        Component(json parms);
        ~Component();

        // Start Grabbing
        void start();
        FrameResult grab_frame(Frame &output_frame);
        int get_max_buffer_size();

        // Stop Grabbing
        void stop();
        void restart();

    private:
        std::string m_camera_label;
        std::string m_camera_name;

        std::vector<RequestData> m_image_buffer;

        bool m_grabbing;
        int m_max_output_buffer;
        int m_frame_seq;

        std::unique_ptr<WebServer> m_web_server;
    };

} // namespace input_endpoint
