#include "place_manager.h"

#include <glog/logging.h>

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------

Placeholder::Placeholder(std::string place_id, std::string place_name, int buffer_max_size, int max_num_buffers):
    m_place_id(place_id),
    m_place_name(place_name),
    m_buffer_max_size(buffer_max_size),
    m_max_num_buffers(max_num_buffers),
    m_place_mutex(std::make_shared<std::mutex>()),
    m_filled_frames(0),
    m_consumed_frames(0),
    m_dropped_frames(0)
{
    create_new_buffer(m_buffer_max_size);
};
// --------------------------------------------------------------------------------------------------------------------------------

Placeholder::Placeholder(Placeholder&& other):
    m_place_id(std::move(other.m_place_id)),
    m_place_name(std::move(other.m_place_name)),
    m_buffer_max_size(std::move(other.m_buffer_max_size)),
    m_max_num_buffers(std::move(other.m_max_num_buffers)),
    m_buffer_map(std::move(other.m_buffer_map)),
    m_subscribers(std::move(other.m_subscribers)),
    m_place_mutex(std::move(other.m_place_mutex)),
    m_filled_frames(0),
    m_consumed_frames(0),
    m_dropped_frames(0)
{};
// --------------------------------------------------------------------------------------------------------------------------------

Placeholder::~Placeholder()
{
    for (auto fr : m_buffer_map)
    {
        delete[] fr.second.frame.mem_buffer.buf_ptr;
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameHandle Placeholder::create_new_buffer(int buffer_size)
{
    FrameHandle id = m_buffer_map.size();
    if (buffer_size > m_buffer_max_size)
        m_buffer_max_size = buffer_size;

    FrameBuf buffer;
    buffer.frame.id = id;
    buffer.frame.mem_buffer.buf_ptr = new char[buffer_size];
    buffer.frame.mem_buffer.buffer_size = buffer_size;
    buffer.frame.type = FrameType::CHAR_BUFFER;
    buffer.state = FrameState::EMPTY;
    buffer.lease_time = chrono::system_clock::now();

    m_buffer_map.insert({id, buffer});

    return id;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Placeholder::restart_place(int buffer_size)
{
    std::lock_guard<std::mutex> lk(*m_place_mutex);

    for (auto& its : m_buffer_map)
    {
        std::chrono::milliseconds leased_time;
        if (m_buffer_map[its.first].state == FrameState::FILLED)
        {
            bool all_filled = true;
            string subscriber_name;
            bsoncxx::oid subscriber_id;
            for (auto& subscriber : m_buffer_map[its.first].subscriber_list)
                if ((subscriber.state != FrameState::FILLED) && (subscriber.state != FrameState::EMPTY))
                {
                    all_filled = false;
                    leased_time = std::chrono::duration_cast<std::chrono::milliseconds>(chrono::system_clock::now() - subscriber.lease_time);
                    subscriber_name = subscriber.name;
                    subscriber_id = subscriber.id;
                    break;
                }

            if (all_filled)
            {
                m_buffer_map[its.first].state = FrameState::EMPTY;
                m_buffer_map[its.first].lease_time = chrono::system_clock::now();
            }
            else
            {
                if (leased_time > 2000ms)
                    LOG(WARNING) << "Subscriber Allocated leased time exceeded maximum: " << leased_time.count() << " - Subscriber: " << subscriber_name << " - subscriber_id: " << subscriber_id.to_string();
            }
        }
        else if (m_buffer_map[its.first].state == FrameState::ALLOCATED)
        {
            leased_time = std::chrono::duration_cast<std::chrono::milliseconds>(chrono::system_clock::now() - m_buffer_map[its.first].lease_time);
            if (leased_time > 2000ms)
                LOG(WARNING) << "Frame Allocated leased time exceeded maximum: " << leased_time.count();
        }
    }

    m_filled_frames = 0;
    m_consumed_frames = 0;
    m_dropped_frames = 0;
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult Placeholder::get_empty_frame(int buffer_size, Frame& ret_frame)
{
    std::lock_guard<std::mutex> lk(*m_place_mutex);

    multimap<chrono::time_point<chrono::system_clock>, FrameHandle> sorted_map;
    for (auto& its : m_buffer_map)
        sorted_map.insert({ its.second.lease_time, its.first });

    int count_filled = 0;
    int count_allocated = 0;
    for (auto& itf : sorted_map)
    {
        if (m_buffer_map[itf.second].state == FrameState::FILLED)
            count_filled++;
        else if (m_buffer_map[itf.second].state == FrameState::ALLOCATED)
            count_allocated++;

        if ((m_buffer_map[itf.second].state == FrameState::EMPTY) && (m_buffer_map[itf.second].frame.mem_buffer.buffer_size >= buffer_size))
        {
            m_buffer_map[itf.second].state = FrameState::ALLOCATED;
            m_buffer_map[itf.second].lease_time = chrono::system_clock::now();

            ret_frame.id = itf.second;
            ret_frame.mem_buffer = m_buffer_map[itf.second].frame.mem_buffer;
            return FrameResult::FRAME_OK;
        }
    }

    if (m_buffer_map.size() < m_max_num_buffers)
    {
        FrameHandle id = create_new_buffer(buffer_size);

        for (auto& sub : m_subscribers)
        {
            m_buffer_map[id].subscriber_list.push_back(sub);
        }

        if ((m_buffer_map.size() % 20) == 0)
        {
            LOG(INFO) << m_place_id << "-" << m_place_name << " - Created new buffer size: " << m_buffer_max_size << " - Total buffers: " << m_buffer_map.size();
            auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(sorted_map.rbegin()->first - sorted_map.begin()->first);
            LOG(INFO) << m_place_id << "-" << m_place_name << " - Filled: " << to_string(count_filled) << " - Allocated: " << to_string(count_allocated) << " - FPS: " << sorted_map.size() / (milliseconds.count() / 1000.0);
        }

        m_buffer_map[id].state = FrameState::ALLOCATED;
        ret_frame.id = id;
        ret_frame.mem_buffer = m_buffer_map[id].frame.mem_buffer;

        return FrameResult::FRAME_OK;
    }

    for (auto& itf : sorted_map)
    {
        if ((m_buffer_map[itf.second].state == FrameState::FILLED) && (m_buffer_map[itf.second].frame.mem_buffer.buffer_size >= buffer_size))
        {
            bool all_filled = true;
            for (auto& subscriber : m_buffer_map[itf.second].subscriber_list)
            {
                if ((subscriber.state != FrameState::FILLED) && (subscriber.state != FrameState::EMPTY))
                {
                    all_filled = false;
                    break;
                }
            }

            if (all_filled)
            {
                // auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(sorted_map.rbegin()->first - sorted_map.begin()->first);

                m_buffer_map[itf.second].state = FrameState::ALLOCATED;
                m_buffer_map[itf.second].lease_time = chrono::system_clock::now();

                ret_frame.id = itf.second;
                ret_frame.mem_buffer = m_buffer_map[itf.second].frame.mem_buffer;

                m_dropped_frames++;
                // if (((m_dropped_frames < 100) && (m_dropped_frames % 10 == 0)) || ((m_dropped_frames >= 100) && (m_dropped_frames % 100 == 0)))
                //     LOG(WARNING) << "Droped frames: " << m_dropped_frames << " - Place: " << m_place_id << " - FPS: " << sorted_map.size() / (milliseconds.count() / 1000.0);

                return FrameResult::FRAME_OK;
            }
        }
    }

    LOG(WARNING) << m_place_id << "-" << m_place_name << " - Has no empty frame";
    return FrameResult::FRAME_INVALID;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Placeholder::release_empty_frame(FrameHandle frame_id)
{
    std::lock_guard<std::mutex> lk(*m_place_mutex);

    if (m_buffer_map[frame_id].state != FrameState::ALLOCATED)
    {
        string err_msg = "Fail updating frame " + m_place_id + "-" + m_place_name + ":" + to_string(frame_id) + " - Frame not allocated";
        LOG(ERROR) << err_msg;
        throw runtime_error(err_msg);
    }

    m_buffer_map[frame_id].state = FrameState::EMPTY;
    m_buffer_map[frame_id].lease_time = chrono::system_clock::now();
}
// --------------------------------------------------------------------------------------------------------------------------------

void Placeholder::update_frame(FrameHandle frame_id, json frame_data)
{
    std::lock_guard<std::mutex> lk(*m_place_mutex);

    if (m_buffer_map[frame_id].state != FrameState::ALLOCATED)
    {
        string err_msg = "Fail updating frame " + m_place_id + "-" + m_place_name + " - Frame: " + to_string(frame_id) + " - Frame not allocated";
        LOG(ERROR) << err_msg;
        // throw runtime_error(err_msg);
        return;
    }

    m_buffer_map[frame_id].state = FrameState::FILLED;
    m_buffer_map[frame_id].frame.frame_data = frame_data;
    m_buffer_map[frame_id].lease_time = chrono::system_clock::now();

    for (auto& subscriber : m_buffer_map[frame_id].subscriber_list)
    {
        subscriber.state = FrameState::FILLED;
    }

    m_filled_frames++;
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult Placeholder::get_filled_frame(bsoncxx::oid subscriber_id, Frame& ret_frame)
{
    std::lock_guard<std::mutex> lk(*m_place_mutex);

    multimap<chrono::time_point<chrono::system_clock>, FrameHandle> sorted_map;
    for (auto& its : m_buffer_map)
    {
        sorted_map.insert({ its.second.lease_time, its.first });
    }

    for (auto& itf : sorted_map)
    {
        if (m_buffer_map[itf.second].state == FrameState::FILLED)
        {
            for (auto& subscriber : m_buffer_map[itf.second].subscriber_list)
            {
                if ((subscriber.id == subscriber_id) && (subscriber.state == FrameState::FILLED))
                {
                    subscriber.state = FrameState::ALLOCATED;
                    subscriber.lease_time = chrono::system_clock::now();
                    ret_frame = m_buffer_map[itf.second].frame;
                    return FrameResult::FRAME_OK;
                }
            }
        }
    }

    // LOG(WARNING) << "Has no filled frame";
    return FrameResult::FRAME_INVALID;
}
// --------------------------------------------------------------------------------------------------------------------------------

void Placeholder::release_frame(FrameHandle frame_id, bsoncxx::oid subscriber_id, bool linked)
{
    std::lock_guard<std::mutex> lk(*m_place_mutex);

    if (m_buffer_map[frame_id].state != FrameState::FILLED)
    {
        string err_msg = "Fail releasing frame " + m_place_id + "-" + m_place_name + ":" + to_string(frame_id) + " - Frame not filled - Subscriber id: " + subscriber_id.to_string();
        LOG(ERROR) << err_msg;
        // throw runtime_error(err_msg);
        for (auto& subscriber : m_buffer_map[frame_id].subscriber_list)
        {
            LOG(ERROR) << "subscriber: " << subscriber.name << " - id: " << subscriber.id.to_string() << " - state: " << (int)(subscriber.state);
        }

        return;
    }

    FrameState new_state;
    if (linked)
        new_state = FrameState::LINKED;
    else
        new_state = FrameState::EMPTY;

    for (auto& subscriber : m_buffer_map[frame_id].subscriber_list)
    {
        if ((subscriber.id == subscriber_id) && (subscriber.state == FrameState::ALLOCATED))
        {
            subscriber.state = new_state;
            bool all_empty = true;
            for (auto subs : m_buffer_map[frame_id].subscriber_list)
            {
                if (subs.state != FrameState::EMPTY)
                {
                    all_empty = false;
                    break;
                }
            }

            if (all_empty)
            {
                m_buffer_map[frame_id].state = new_state;
                m_consumed_frames++;
            }

            return;
        }
    }

    string err_msg = "Fail releasing frame " + m_place_id + "-" + m_place_name + ":" + to_string(frame_id) + " - Frame not allocated to subscriber";
    LOG(ERROR) << err_msg;
    throw runtime_error(err_msg);
}
// --------------------------------------------------------------------------------------------------------------------------------

void Placeholder::add_subscriber(bsoncxx::oid subscriber_id, string subscriber_name)
{
    std::lock_guard<std::mutex> lk(*m_place_mutex);

    Subscriber sub;
    sub.id = subscriber_id;
    sub.name = subscriber_name;
    sub.state = FrameState::EMPTY;

    m_subscribers.push_back(sub);

    for (auto& its : m_buffer_map)
    {
        its.second.subscriber_list.push_back(sub);
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

void Placeholder::log_history(int microseconds)
{
    // auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(sorted_map.rbegin()->first - sorted_map.begin()->first);
    LOG(INFO) << "Place: " << m_place_id << "-" << m_place_name << \
         " - FPS: " << setprecision(2) << m_filled_frames / (microseconds / 1e6) << \
         " - Filled: " << m_filled_frames << \
         " - Consumed: " << m_consumed_frames << \
         " - Droped: " << m_dropped_frames;

    m_filled_frames = 0;
    m_consumed_frames = 0;
    m_dropped_frames = 0;
}
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------

PlaceManager::PlaceManager(int max_frames):
    m_max_frames(max_frames)
{};
// --------------------------------------------------------------------------------------------------------------------------------

void PlaceManager::create_new_place(std::string place_id, std::string place_name, int buffer_size, int max_num_buffers)
{
    LOG(INFO) << "Creating new placeholder: " << place_id << "-" << place_name;

    std::unique_lock<std::shared_timed_mutex> lk(m_map_mutex);
    m_placeholders.emplace(place_id, Placeholder(place_id, place_name, buffer_size, max_num_buffers));
}
// --------------------------------------------------------------------------------------------------------------------------------

void PlaceManager::restart_place(std::string place_id, int buffer_size)
{
    std::shared_lock<std::shared_timed_mutex> lk(m_map_mutex);

    auto it = m_placeholders.find(place_id);
    if (it == m_placeholders.end())
        throw std::runtime_error("Invalid place id: " + place_id);

    it->second.restart_place(buffer_size);
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult PlaceManager::get_empty_frame(string place_id, int buffer_size, Frame& ret_frame)
{
    std::shared_lock<std::shared_timed_mutex> lk(m_map_mutex);

    auto it = m_placeholders.find(place_id);
    if (it == m_placeholders.end())
        throw std::runtime_error("Invalid place id: " + place_id);

    return it->second.get_empty_frame(buffer_size, ret_frame);
}
// --------------------------------------------------------------------------------------------------------------------------------

void PlaceManager::release_empty_frame(string place_id, FrameHandle frame_id)
{
    std::shared_lock<std::shared_timed_mutex> lk(m_map_mutex);

    auto it = m_placeholders.find(place_id);
    if ( it == m_placeholders.end() )
    {
        string err_msg = "Fail updating frame " + string(place_id) + " - Placeholder not found";
        LOG(ERROR) << err_msg;
        throw runtime_error(err_msg);
    }

    it->second.release_empty_frame(frame_id);
}
// --------------------------------------------------------------------------------------------------------------------------------

void PlaceManager::update_frame(string place_id, FrameHandle frame_id, json frame_data)
{
    std::shared_lock<std::shared_timed_mutex> lk(m_map_mutex);

    auto it = m_placeholders.find(place_id);
    if ( it == m_placeholders.end() )
    {
        string err_msg = "Fail updating frame " + string(place_id) + " - Placeholder not found";
        LOG(ERROR) << err_msg;
        throw runtime_error(err_msg);
    }

    it->second.update_frame(frame_id, frame_data);
}
// --------------------------------------------------------------------------------------------------------------------------------

FrameResult PlaceManager::get_filled_frame(std::string place_id, bsoncxx::oid subscriber_id, Frame& ret_frame)
{
    std::shared_lock<std::shared_timed_mutex> lk(m_map_mutex);

    auto it = m_placeholders.find(place_id);
    if ( it == m_placeholders.end() )
    {
        string err_msg = "Fail alocating frame " + string(place_id) + " - Placeholder not found";
        LOG(ERROR) << err_msg;
        throw runtime_error(err_msg);
    }

    return it->second.get_filled_frame(subscriber_id, ret_frame);
}
// --------------------------------------------------------------------------------------------------------------------------------

void PlaceManager::release_frame(string place_id, FrameHandle frame_id, bsoncxx::oid subscriber_id, bool linked)
{
    std::shared_lock<std::shared_timed_mutex> lk(m_map_mutex);

    auto it = m_placeholders.find(place_id);
    if ( it == m_placeholders.end() )
    {
        string err_msg = "Fail releasing frame " + string(place_id) + " - Placeholder not found";
        LOG(ERROR) << err_msg;
        throw runtime_error(err_msg);
    }

    it->second.release_frame(frame_id, subscriber_id, linked);
}
// --------------------------------------------------------------------------------------------------------------------------------

void PlaceManager::add_subscriber(string place_id, bsoncxx::oid subscriber_id, string subscriber_name)
{
    std::shared_lock<std::shared_timed_mutex> lk(m_map_mutex);

    auto it = m_placeholders.find(place_id);
    if ( it == m_placeholders.end() )
    {
        string err_msg = "Fail adding subscriber to place " + string(place_id) + " - Placeholder not found";
        LOG(ERROR) << err_msg;
        throw runtime_error(err_msg);
    }

    it->second.add_subscriber(subscriber_id, subscriber_name);
}
// --------------------------------------------------------------------------------------------------------------------------------

void PlaceManager::log_history(int microseconds)
{
    std::shared_lock<std::shared_timed_mutex> lk(m_map_mutex);
    for (auto& its : m_placeholders)
    {
        its.second.log_history(microseconds);
    }
}
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
