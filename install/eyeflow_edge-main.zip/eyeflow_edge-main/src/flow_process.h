#pragma once

#include <list>

#include <nlohmann/json.hpp>
using json = nlohmann::json;

#include "place_manager.h"
#include "node_component.h"
#include "frame_event.h"
#include <env_var.h>

#include "video_test/video_test.h"
#include "image_test/image_test.h"

#define MAX_NUM_BUFFERS 100
#define LOG_HISTORY_TIME 60e6
//---------------------------------------------------------------------------------------------------------------------------------

class FlowProcess
{
public:
    FlowProcess(const json &flow_data, const json &process_parms);
    ~FlowProcess() = default;

    void process_flow(bool* thd_ctrl);

private:
    json m_flow_data;
    json m_process_parms;
    PlaceManager m_place_manager;
    bool m_thread_state;
    char m_key_pressed;
    common::EnvVar *m_env_var;

    std::list<NodeComponent> m_node_list;
    void parse_flow();

    std::list<std::shared_ptr<video_test::Component>> m_video_test_list;
    std::list<std::shared_ptr<image_test::Component>> m_image_test_list;

    std::list<std::shared_ptr<FrameEvent>> m_frame_event_component_list;
    json get_frame_data();

    void add_consumer_to_nodes();
    void start_nodes_thread();

    std::chrono::time_point<std::chrono::system_clock> m_last_log;

    void thd_streamer(NodeComponent* node);
    void thd_consumer(NodeComponent* node);
    void thd_processor(NodeComponent* node);
    void thd_annotator(NodeComponent* node);
};
// --------------------------------------------------------------------------------------------------------------------------------
