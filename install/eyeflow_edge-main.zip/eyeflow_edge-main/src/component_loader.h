#pragma once

#include <nlohmann/json.hpp>
using json = nlohmann::json;

#include "frame_component.h"
#include "frame_streamer.h"
#include "frame_processor.h"
#include "frame_annotator.h"
#include "frame_consumer.h"
#include "frame_event.h"
//---------------------------------------------------------------------------------------------------------------------------------

using frame_streamer_creator_t = FrameStreamer* (*)(json);
using frame_processor_creator_t = FrameProcessor* (*)(json);
using frame_annotator_creator_t = FrameAnnotator* (*)(json);
using frame_consumer_creator_t = FrameConsumer* (*)(json);
using frame_event_creator_t = FrameEvent* (*)(json);

struct ComponentLib
{
    std::string component_id;
    std::string component_name;
    void* lib_handler = nullptr;
};

//---------------------------------------------------------------------------------------------------------------------------------

class ComponentLoader
{
public:
    static std::shared_ptr<ComponentLoader> instance()
    {
        static std::shared_ptr<ComponentLoader> inst(new ComponentLoader);
        return inst;
    }

    std::shared_ptr<FrameStreamer> load_component_streamer(json component_node);
    std::shared_ptr<FrameProcessor> load_component_processor(json component_node);
    std::shared_ptr<FrameEvent> load_component_event(json component_node);
    std::shared_ptr<FrameConsumer> load_component_consumer(json component_node);
    std::shared_ptr<FrameAnnotator> load_component_annotator(json component_node);

    ComponentLoader(ComponentLoader&&) = delete;
    ComponentLoader(const ComponentLoader&) = delete;
    void operator=(const ComponentLoader&) = delete;

private:
    ComponentLoader(){};

    std::map<std::string, ComponentLib> component_libs;
    ComponentLib get_component_lib(json component_node);

    static void reset_dlerror();
    static void check_dlerror();
};
//---------------------------------------------------------------------------------------------------------------------------------
