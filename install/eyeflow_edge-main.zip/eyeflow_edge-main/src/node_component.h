#pragma once

#include <string>
#include <set>
#include <deque>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>

#include <nlohmann/json.hpp>
using json = nlohmann::json;

#include <bsoncxx/oid.hpp>

#include "frame_component.h"
#include "frame_streamer.h"
#include "frame_processor.h"
#include "frame_annotator.h"
#include "frame_consumer.h"
//---------------------------------------------------------------------------------------------------------------------------------

struct NodeInput {
    NodeInput(bsoncxx::oid p_id, std::shared_ptr<std::atomic_bool> p_has_data, std::shared_ptr<std::condition_variable> p_c_var, std::shared_ptr<std::mutex> p_cv_mutex):
        id(p_id),
        c_var(p_c_var),
        cv_mutex(p_cv_mutex),
        has_data(p_has_data)
    {};

    NodeInput(const NodeInput& other):
        id(other.id),
        c_var(other.c_var),
        cv_mutex(other.cv_mutex),
        has_data(other.has_data)
    {};

    NodeInput(NodeInput&& other):
        id(std::move(other.id)),
        c_var(std::move(other.c_var)),
        cv_mutex(std::move(other.cv_mutex)),
        has_data(std::move(other.has_data))
    {};

    bsoncxx::oid id;
    std::shared_ptr<std::atomic_bool> has_data;
    std::shared_ptr<std::condition_variable> c_var;
    std::shared_ptr<std::mutex> cv_mutex;
};
//---------------------------------------------------------------------------------------------------------------------------------

class NodeComponent {
public:
    NodeComponent(json node_data);

    void load_component();

    void notify_consumers();

    void reset_inputs();
    bool input_ready();

    bool has_all_inputs();
    bool has_any_input();

    void add_consumer(NodeComponent& consumer);
    std::shared_ptr<NodeInput> get_node_input(bsoncxx::oid id);

    std::shared_ptr<FrameConsumer> m_consumer;
    std::shared_ptr<FrameStreamer> m_streamer;
    std::shared_ptr<FrameProcessor> m_processor;
    std::shared_ptr<FrameAnnotator> m_annotator;
    std::shared_ptr<std::thread> m_thd_processor;

    int m_buf_max_size;

    bsoncxx::oid id;
    std::set<bsoncxx::oid> inputs_id;
    std::set<bsoncxx::oid> outputs_id;

    std::shared_ptr<std::condition_variable> m_cvar;
    std::shared_ptr<std::mutex> m_cv_mutex;

    std::deque<NodeInput> m_input_list;
    std::deque<std::shared_ptr<NodeInput>> m_consumer_list;

    std::string m_component_name;
    std::string m_component_type;
    bool m_wait_inputs;

    json m_node_data;
};
//---------------------------------------------------------------------------------------------------------------------------------
