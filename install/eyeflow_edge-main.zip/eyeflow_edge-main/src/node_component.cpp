#include <glog/logging.h>

#include "node_component.h"

#include "component_loader.h"

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------

NodeComponent::NodeComponent(json node_data):
    m_node_data(node_data),
    m_cvar(std::make_shared<std::condition_variable>()),
    m_cv_mutex(std::make_shared<std::mutex>()),
    m_streamer(nullptr),
    m_consumer(nullptr),
    m_processor(nullptr),
    m_annotator(nullptr),
    m_thd_processor(nullptr),
    m_buf_max_size(0)
{
    id = bsoncxx::oid(m_node_data["_id"].get<string>());
    if (m_node_data.contains("outputs"))
        for (auto out : m_node_data["outputs"].items())
        {
            for (auto dest : out.value().at("nodes"))
            {
                auto out_id = bsoncxx::oid(dest.get<string>());
                outputs_id.insert(out_id);
            }
        }

    m_component_name = m_node_data["options"]["component"].get<string>();
    if (!m_node_data["options"].contains("process_type"))
        throw std::runtime_error("Component lacking [options][process_type] info: " + m_node_data.dump());

    m_component_type = m_node_data["options"]["process_type"].get<string>();
    m_wait_inputs = m_node_data["options"].value("wait_inputs", false);
};
// --------------------------------------------------------------------------------------------------------------------------------

void NodeComponent::load_component()
{
    if (m_component_type == "streamer" )
    {
        LOG(INFO) << "load_component_input:" << m_node_data.value("component_name", "") << " Comp_id: " << m_node_data.value("component_id", "");
        bool bEnabled  = true;
        if(m_node_data["options"].contains("camera_enabled") && m_node_data["options"]["camera_enabled"].is_boolean() )
            bEnabled = m_node_data["options"]["camera_enabled"].get<bool>();

        if(bEnabled)
        {
            m_streamer = ComponentLoader::instance()->load_component_streamer(m_node_data);
            m_buf_max_size = m_streamer->get_max_buffer_size();
        }
    }
    else if (m_component_type == "processor")
    {
        m_processor = ComponentLoader::instance()->load_component_processor(m_node_data);
        m_buf_max_size = m_processor->get_max_buffer_size();
    }
    else if ((m_component_type == "consumer"))
    {
        m_consumer = ComponentLoader::instance()->load_component_consumer(m_node_data);
    }
    else if ((m_component_type == "annotator"))
    {
        m_annotator = ComponentLoader::instance()->load_component_annotator(m_node_data);
    }
};
// --------------------------------------------------------------------------------------------------------------------------------

void NodeComponent::notify_consumers()
{
    for (auto &consumer : m_consumer_list)
    {
        {
            std::lock_guard<std::mutex> lk(*(consumer->cv_mutex));
            *(consumer->has_data) = true;
        }
        consumer->c_var->notify_one();
    }
};
// --------------------------------------------------------------------------------------------------------------------------------

bool NodeComponent::input_ready()
{
    if (m_wait_inputs)
        return has_all_inputs();
    else
        return has_any_input();
}
// --------------------------------------------------------------------------------------------------------------------------------

bool NodeComponent::has_all_inputs()
{
    for (auto input_it = m_input_list.begin(); input_it != m_input_list.end(); input_it++)
    {
        if (!*input_it->has_data)
            return false;
    }

    return true;
};
// --------------------------------------------------------------------------------------------------------------------------------

bool NodeComponent::has_any_input()
{
    for (auto input_it = m_input_list.begin(); input_it != m_input_list.end(); input_it++)
    {
        if (*input_it->has_data)
            return true;
    }

    return false;
};
// --------------------------------------------------------------------------------------------------------------------------------

void NodeComponent::reset_inputs()
{
    for (auto input_it = m_input_list.begin(); input_it != m_input_list.end(); input_it++)
        *(input_it->has_data) = false;

    return;
}
// --------------------------------------------------------------------------------------------------------------------------------

void NodeComponent::add_consumer(NodeComponent& consumer)
{
    m_consumer_list.push_back(consumer.get_node_input(id));
}
// --------------------------------------------------------------------------------------------------------------------------------

std::shared_ptr<NodeInput> NodeComponent::get_node_input(bsoncxx::oid id)
{
    std::shared_ptr<std::atomic_bool> has_data = std::make_shared<std::atomic_bool>();
    *has_data = false;
    m_input_list.emplace_front(
        NodeInput(
            id,
            has_data,
            m_cvar,
            m_cv_mutex
        )
    );
    return std::make_shared<NodeInput>(*m_input_list.begin());
};
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
