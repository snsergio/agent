#include <memory>
#include <string>
#include <vector>
#include <deque>
#include <chrono>
#include <thread>
#include <mutex>
#include <condition_variable>

#include <termios.h>

#include <glog/logging.h>

#include "flow_process.h"
#include "component_loader.h"

#include <nlohmann/json.hpp>
using json = nlohmann::json;
extern json g_eyeflow_conf;

using namespace std;
// --------------------------------------------------------------------------------------------------------------------------------

PlaceManager* g_place_manager = nullptr;

FrameResult request_empty_frame(std::string place_id, int buffer_size, Frame& ret_frame)
{
    if (g_place_manager == nullptr)
        throw std::runtime_error("PlaceManager not initialized");

    return g_place_manager->get_empty_frame(place_id, buffer_size, ret_frame);
}
// --------------------------------------------------------------------------------------------------------------------------------

FlowProcess::FlowProcess(const json &flow_data, const json &process_parms):
    m_flow_data(flow_data),
    m_process_parms(process_parms),
    m_place_manager(100),
    m_thread_state(false),
    m_key_pressed(0)
{
    m_env_var = nullptr;
    g_place_manager = &m_place_manager;
    parse_flow();
}
// --------------------------------------------------------------------------------------------------------------------------------

void FlowProcess::parse_flow()
{
    LOG(INFO) << "Parsing Flow: " << m_flow_data["name"].get<string>();

    // insert all nodes
    for (auto node : m_flow_data["nodes"])
    {
        // LOG(INFO) << "Add node: " << node["_id"].get<string>();
        m_node_list.emplace_back(NodeComponent(node));
    }

    // setup inputs
    for (auto nd = m_node_list.begin(); nd != m_node_list.end(); nd++)
    {
        for (auto nd2 : m_node_list)
        {
            if (nd2.id == nd->id)
                continue;

            if (nd2.outputs_id.find(nd->id) != nd2.outputs_id.end())
                nd->inputs_id.insert(nd2.id);
        }
    }


    bool changed = true;
    while(changed)
    {
        changed = false;
        list<NodeComponent>::iterator it_pos_inputs = m_node_list.end();
        map<bsoncxx::oid, list<NodeComponent>::iterator> id_map;
        for (auto nd_it = m_node_list.begin(); nd_it != m_node_list.end(); nd_it++)
        {
            id_map.insert({nd_it->id, nd_it});
            if (nd_it->inputs_id.size() == 0)
                if (it_pos_inputs != m_node_list.end())
                {
                    m_node_list.insert(it_pos_inputs, *nd_it);
                    m_node_list.erase(nd_it++);
                    changed = true;
                    break;
                }
                else
                    continue;
            else
            {
                if (it_pos_inputs == m_node_list.end())
                    it_pos_inputs = nd_it;

                for (auto out : nd_it->outputs_id)
                {
                    auto pos_id = id_map.find(out);
                    if (pos_id != id_map.end())
                    {
                        m_node_list.insert(pos_id->second, *nd_it);
                        m_node_list.erase(nd_it++);
                        changed = true;
                        break;
                    }
                }

                if (changed)
                    break;
            }
        }
    }

    // log pos
    // for (auto nd : node_list)
    // {
    //     string node_str = "Node: " + nd.id.to_string();

    //     node_str += " - Inputs: -";
    //     for (auto in : nd.inputs)
    //         node_str += in.to_string() + "-";

    //     node_str +=  " - Outputs: -";
    //     for (auto out : nd.outputs)
    //         node_str += out.to_string() + "-";

    //     LOG(INFO) << node_str;
    // }
}
// --------------------------------------------------------------------------------------------------------------------------------

void FlowProcess::process_flow(bool *thd_ctrl)
{
    try
    {
        m_thread_state = true;
        if (!m_process_parms["flow_test"].get<bool>())
        {
            LOG(INFO) << "Load Frame Event Components";
            for (auto node_it = m_node_list.begin(); node_it != m_node_list.end(); node_it++)
            {
                if (node_it->m_component_type != "event")
                    continue;

                m_frame_event_component_list.push_back(ComponentLoader::instance()->load_component_event(node_it->m_node_data));
                shared_ptr<FrameEvent> inspection_manager = m_frame_event_component_list.back();
                inspection_manager->start();
            }
        }

        NodeComponent* video_node = nullptr;
        if (!m_process_parms["service"].get<bool>() && m_process_parms["monitor"].get<bool>())
        {
            LOG(INFO) << "Load Video Show Component";
            json video_node_parms = {
                {"_id", bsoncxx::oid().to_string()},
                {"name", "video_window"},
                {"component_id", "62af39280c84544f709fd5f5"},
                {"component_name", "video_window"},
                {"options", {
                    {"label", "Monitor"},
                    {"m_max_width", 1200},
                    {"m_max_height", 900},
                    {"color", "#967ADC"},
                    {"component", "video_window"},
                    {"process_type", "consumer"}
                }}
            };

            m_node_list.emplace_back(NodeComponent(video_node_parms));
            video_node = &m_node_list.back();
            video_node->load_component();
        }

        LOG(INFO) << "Load all Flow components";
        for (auto node_it = m_node_list.begin(); node_it != m_node_list.end(); node_it++)
        {
            if (
                (!m_process_parms["service"].get<bool>() && m_process_parms["monitor"].get<bool>() && (node_it->id == video_node->id)) ||
                (node_it->m_component_name == "video_save") ||
                (node_it->m_component_type == "event")
            )
                continue;

            LOG(INFO) << "Starting component: " << node_it->m_component_name << " - ID: " << node_it->id.to_string();

            if (m_process_parms["flow_test"].get<bool>())
            {
                node_it->m_node_data["options"]["flow_test"] = true;

                if (node_it->m_component_type == "streamer")
                {
                    if (m_process_parms["video_test"].get<bool>())
                    {
                        string input_name = node_it->m_node_data["options"].value("camera_name", node_it->m_node_data["options"]["label"].get<string>());

                        if (!m_process_parms["video_file"].contains(input_name))
                            throw std::runtime_error("Does not have a video for input: " + input_name);

                        LOG(INFO) << "Video Test: " << input_name << " = " << m_process_parms["video_file"][input_name].get<string>();

                        node_it->m_node_data["options"] = {
                            {"_id", bsoncxx::oid().to_string()},
                            {"name", node_it->m_node_data["name"].get<string>()},
                            {"camera_name", input_name},
                            {"component_id", "62af39280c84544f709fd5f5"},
                            {"component_name", "video_test"},
                            {"phase", "input"},
                            {"process_type", "streamer"},
                            {"label", node_it->m_node_data["options"]["label"].get<string>()},
                            {"video_path", m_process_parms["video_path"]},
                            {"filename", m_process_parms["video_file"][input_name].get<string>()},
                            {"ini_frame", 0},
                            // {"end_frame", 20000},
                            {"component", "video_test"},
                            {"monitor_output", true}
                        };
                    }
                    else if (m_process_parms["image_test"].get<bool>())
                    {
                        string input_name = node_it->m_node_data["options"].value("camera_name", node_it->m_node_data["options"]["label"].get<string>());

                        LOG(INFO) << "Image Test: " << input_name << " = " << m_process_parms["image_path"].get<string>();

                        node_it->m_node_data["options"] = {
                            {"_id", bsoncxx::oid().to_string()},
                            {"name", node_it->m_node_data["name"].get<string>()},
                            {"camera_name", input_name},
                            {"component_id", "62af39280c84544f709fd5f5"},
                            {"component_name", "image_test"},
                            {"phase", "input"},
                            {"process_type", "streamer"},
                            {"label", node_it->m_node_data["options"]["label"].get<string>()},
                            {"image_path", m_process_parms["image_path"]},
                            {"component", "image_test"}
                        };
                    }
                }
                else if (!node_it->m_node_data["options"].value("input_stream_name", "").empty())
                {
                    string input_name = node_it->m_node_data["options"]["input_stream_name"].get<string>();
                    if (!m_process_parms["video_file"].contains(input_name))
                        throw std::runtime_error("Does not have a stream for input: " + input_name);

                    LOG(INFO) << "Video Test: " << input_name << " = " << m_process_parms["video_file"][input_name].get<string>();
                    node_it->m_node_data["options"]["flow_test_file"] = m_process_parms["video_path"].get<string>() + "/" + m_process_parms["video_file"][input_name].get<string>();
                }
            }

            node_it->load_component();
            m_place_manager.create_new_place(node_it->id.to_string(), node_it->m_node_data.value("name", node_it->m_node_data.value("component_name", "")), node_it->m_buf_max_size, MAX_NUM_BUFFERS);

            if (m_process_parms["image_test"].get<bool>() && (node_it->m_node_data["options"].value("component_name", "") == "image_test"))
            {
                m_image_test_list.push_back(std::dynamic_pointer_cast<image_test::Component>(node_it->m_streamer));
            }
            else if(m_process_parms["video_test"].get<bool>() && (node_it->m_node_data["options"].value("component_name", "") == "video_test"))
            {
                m_video_test_list.push_back(std::dynamic_pointer_cast<video_test::Component>(node_it->m_streamer));
            }

            if (!m_process_parms["service"].get<bool>() && m_process_parms["monitor"].get<bool>() && node_it->m_node_data["options"].contains("monitor_output") && node_it->m_node_data["options"]["monitor_output"].get<bool>())
            {
                LOG(INFO) << "Monitor added to component: " << node_it->id.to_string() << " - " << node_it->m_component_name;
                node_it->outputs_id.insert(video_node->id);
                // node_it->m_consumer_list.push_back(video_node->get_node_input(node_it->id));
                // m_place_manager.add_subscriber(node_it->id.to_string(), video_node.id, video_node.m_component_name);
            }

            if (m_process_parms["video_save"].get<bool>() && node_it->m_node_data["options"].contains("video_save_output") && node_it->m_node_data["options"]["video_save_output"].get<bool>())
            {
                LOG(INFO) << "VideoSave added to component: " << node_it->id.to_string() << " - " << node_it->m_component_name;
                json save_options = {
                    {"_id", bsoncxx::oid().to_string()},
                    {"name", "video_save"},
                    {"component_id", "62af39330c84544f709fd5f6"},
                    {"component_name", "video_save"},
                    {"options", {
                        {"label", ""},
                        {"component", "video_save"},
                        {"out_width", 1280},
                        {"out_height", 720},
                        {"skip_frames", 0},
                        {"frame_rate", 10},
                        {"out_path", g_eyeflow_conf["file-service"]["video"].get<std::string>()},
                        {"process_type", "consumer"}
                    }}
                };

                m_node_list.emplace_back(NodeComponent(save_options));
                NodeComponent* save_node = &m_node_list.back();
                save_node->load_component();
                node_it->outputs_id.insert(save_node->id);
            }

            if (node_it->m_node_data["options"].contains("frame_data_save_output") && node_it->m_node_data["options"]["frame_data_save_output"].get<bool>())
            {
                LOG(INFO) << "FrameDataSave added to component: " << node_it->id.to_string() << " - " << node_it->m_component_name;
                json save_options = {
                    {"_id", bsoncxx::oid().to_string()},
                    {"name", "frame_data_save_" + node_it->id.to_string()},
                    {"component_id", "64071723348548afe9379fdf"},
                    {"component_name", "frame_data_save"},
                    {"options", {
                        {"label", ""},
                        {"component", "frame_data_save"},
                        {"out_path", g_eyeflow_conf["file-service"]["video"].get<std::string>()},
                        {"process_type", "consumer"}
                    }}
                };

                m_node_list.emplace_back(NodeComponent(save_options));
                NodeComponent* save_node = &m_node_list.back();
                save_node->load_component();
                node_it->outputs_id.insert(save_node->id);
            }
        }

        add_consumer_to_nodes();
        start_nodes_thread();

        struct termios oldSettings;

        if (!m_process_parms["service"].get<bool>())
        {
            tcgetattr(fileno(stdin), &oldSettings);
            struct termios newSettings = oldSettings;
            newSettings.c_lflag &= (~ICANON & ~ECHO);
            tcsetattr(fileno(stdin), TCSANOW, &newSettings);

            LOG(INFO) << "Check input keyboard";
        }

        m_last_log = std::chrono::system_clock::now();
        while (*thd_ctrl)
        {
            fd_set set;
            struct timeval tv;

            tv.tv_sec = 0;
            tv.tv_usec = 500000;

            m_key_pressed = 0;
            if (!m_process_parms["service"].get<bool>())
            {
                FD_ZERO(&set);
                FD_SET(fileno(stdin), &set);

                int res = select(fileno(stdin) + 1, &set, NULL, NULL, &tv);

                if (res > 0)
                {
                    char c;
                    auto ret = read(fileno(stdin), &c, 1);
                    if ((c >= '0') && (c <= 'z'))
                    {
                        m_key_pressed = c;
                        LOG(INFO) << "Key pressed: " << c;
                        if(c == 'q') {
                            break;
                        }
                    }
                }
            }

            if (m_process_parms["flow_test"].get<bool>())
            {
                bool all_tests_stoped = true;
                for (auto node : m_video_test_list)
                {
                    if (node->is_opened())
                    {
                        all_tests_stoped = false;
                        break;
                    }
                }

                for (auto node : m_image_test_list)
                {
                    if (node->is_opened())
                    {
                        all_tests_stoped = false;
                        break;
                    }
                }

                if (all_tests_stoped)
                {
                    LOG(INFO) << "Flow Test - All tests finished";
                    this_thread::sleep_for(1s);
                    break;
                }
            }

            auto microseconds = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - m_last_log);
            if (microseconds.count() > LOG_HISTORY_TIME)
            {
                m_place_manager.log_history(microseconds.count());
                m_last_log = std::chrono::system_clock::now();
            }

            this_thread::sleep_for(200ms);
        }

        if (!m_process_parms["service"].get<bool>())
            tcsetattr(fileno(stdin), TCSANOW, &oldSettings);

        m_thread_state = false;

        for (auto node_it = m_node_list.begin(); node_it != m_node_list.end(); node_it++)
        {
            node_it->notify_consumers();
            if (node_it->m_thd_processor != nullptr)
                if (node_it->m_thd_processor->joinable())
                    node_it->m_thd_processor->join();
        }
    }
    catch (std::exception &excpt)
    {
        LOG(ERROR) << "Fail starting flow: " << excpt.what();
        return;
    }
    catch (...)
    {
        LOG(ERROR) << "Fail starting flow";
        return;
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

void FlowProcess::add_consumer_to_nodes()
{
    for (auto node_it = m_node_list.begin(); node_it != m_node_list.end(); node_it++)
    {
        for (auto out_node_id : node_it->outputs_id)
        {
            for (auto node_out_it = m_node_list.begin(); node_out_it != m_node_list.end(); node_out_it++)
            {
                if (node_out_it->id == out_node_id)
                {
                    LOG(INFO) << "Add Consumer to Node: " << node_it->id.to_string() << " -> " << node_out_it->id.to_string();
                    node_it->add_consumer(*node_out_it);
                    // node_it->m_consumer_list.push_back(node_out_it->get_node_input(node_it->id));
                    m_place_manager.add_subscriber(node_it->id.to_string(), node_out_it->id, node_out_it->m_component_name);
                    break;
                }
            }
        }
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

void FlowProcess::start_nodes_thread()
{
    LOG(INFO) << "Start all nodes";
    for (auto node_it = m_node_list.begin(); node_it != m_node_list.end(); node_it++)
    {
        if (node_it->m_component_type == "streamer")
        {
            node_it->m_streamer->start();
        }
        else if (node_it->m_component_type == "processor")
        {
            node_it->m_processor->start();
        }
        else if (node_it->m_component_type == "consumer")
        {
            node_it->m_consumer->start();
        }
        else if (node_it->m_component_type == "annotator")
        {
            node_it->m_annotator->start();
        }
    }

    LOG(INFO) << "Start node threads";

    for (auto node_it = m_node_list.rbegin(); node_it != m_node_list.rend(); node_it++)
    {
        if (node_it->m_component_type == "streamer")
        {
            node_it->m_thd_processor = std::make_shared<std::thread>(&FlowProcess::thd_streamer, this, &(*node_it));
        }
        else if (node_it->m_component_type == "processor")
        {
            node_it->m_thd_processor = std::make_shared<std::thread>(&FlowProcess::thd_processor, this, &(*node_it));
        }
        else if (node_it->m_component_type == "consumer")
        {
            node_it->m_thd_processor = std::make_shared<std::thread>(&FlowProcess::thd_consumer, this, &(*node_it));
        }
        else if (node_it->m_component_type == "annotator")
        {
            node_it->m_thd_processor = std::make_shared<std::thread>(&FlowProcess::thd_annotator, this, &(*node_it));
        }
    }
};
// --------------------------------------------------------------------------------------------------------------------------------

json FlowProcess::get_frame_data()
{
    if(m_env_var == nullptr)
    {
        m_env_var = common::EnvVar::get_instance();
    }

    json frame_data;
    if (m_key_pressed == 0)
        frame_data["key_press"] = "";
    else if (m_key_pressed >= '0' && m_key_pressed <= 'z')
        frame_data["key_press"] = string(1, m_key_pressed);

    if (m_process_parms["flow_test"].get<bool>())
        frame_data["flow_test"] = true;

    if (m_key_pressed == 's')
        m_env_var->update_variable("video_save_keyboard", true);
    else if (m_key_pressed == 'a')
        m_env_var->update_variable("video_save_keyboard", false);

    if (m_key_pressed == 'j')
        m_env_var->update_variable("video_save_conveyor", true);
    else if (m_key_pressed == 'k')
        m_env_var->update_variable("video_save_conveyor", false);

    frame_data["env_var"] = m_env_var->get_var();

    return frame_data;
}
// --------------------------------------------------------------------------------------------------------------------------------

void FlowProcess::thd_streamer(NodeComponent* node)
{
    LOG(INFO) << "thd_stream started Streamer: " << node->id.to_string();// << " node: " << node->m_component_name;
    int no_frames = 0;
    int bad_frames = 0;
    bool this_thread_state = true;
    Frame frame_buffer;

    string last_surface_state;
    while (m_thread_state && this_thread_state)
    {
        try
        {
            if (m_place_manager.get_empty_frame(node->id.to_string(), node->m_streamer->get_max_buffer_size(), frame_buffer) != FrameResult::FRAME_OK)
            {
                // node.notify_consumers();
                this_thread::sleep_for(10ms);
                no_frames++;
                if ((no_frames > 30) && (m_process_parms["flow_test"].get<bool>()))
                {
                    this_thread::sleep_for(500ms);
                    continue;
                }

                if (no_frames > MAX_BAD_FRAMES)
                {
                    LOG(ERROR) << node->id.to_string() << " - Fail in sync threads. Aborting!";
                    this_thread_state = false;
                    break;
                }
                continue;
            }

            no_frames = 0;

            frame_buffer.frame_data = get_frame_data();
            if (frame_buffer.frame_data["env_var"].contains("inspection_manager") && frame_buffer.frame_data["env_var"]["inspection_manager"]["cam_state"].contains(node->m_streamer->get_name()))
            {
                frame_buffer.frame_data.update(frame_buffer.frame_data["env_var"]["inspection_manager"]["cam_state"][node->m_streamer->get_name()]);
            }

            if (node->m_streamer->grab_frame(frame_buffer) != FrameResult::FRAME_OK)
            {
                // LOG(INFO) << "Received bad frame";
                m_place_manager.release_empty_frame(node->id.to_string(), frame_buffer.id);
                this_thread::sleep_for(20ms);
                bad_frames++;
                if (bad_frames > MAX_BAD_FRAMES)
                {
                    LOG(ERROR) << node->id.to_string() << " - Too many bad_frames. Aborting!";
                    //this_thread_state = false;
                    LOG(INFO) << node->id.to_string() << " Starting";
                    node->m_streamer->stop();
                    this_thread::sleep_for(1000ms);
                    node->m_streamer->start();
                    LOG(INFO) << node->id.to_string() << " Started";
                    bad_frames = 0;
                    //break;
                }
                continue;
            }

            if ((frame_buffer.frame_data.value("surface_state", "") != last_surface_state && frame_buffer.frame_data.value("surface_state", "") == "surface_begin") ||
                (m_key_pressed == 'z'))
            {
                LOG(INFO) << "Restarting frame buffers";
                m_place_manager.restart_place(node->id.to_string(), node->m_streamer->get_max_buffer_size());
                m_place_manager.release_empty_frame(node->id.to_string(), frame_buffer.id);
                this_thread::sleep_for(20ms);
                last_surface_state = frame_buffer.frame_data.value("surface_state", "");
                continue;
            }
        }
        catch (std::exception &excpt)
        {
            LOG(ERROR) << node->id.to_string() << " - Fail grabbing frame: " << excpt.what();
            m_place_manager.release_empty_frame(node->id.to_string(), frame_buffer.id);
            this_thread::sleep_for(50ms);
            bad_frames++;
            if (bad_frames > MAX_BAD_FRAMES)
            {
                LOG(ERROR) << node->id.to_string() << " - Too many bad_frames. Aborting!";
                node->m_streamer->restart();
                // this_thread_state = false;
                // break;
                node->m_streamer->stop();
                //this_thread::sleep_for(2000ms);
                node->m_streamer->start();
                LOG(INFO) << node->id.to_string() << " Started";
                bad_frames = 0;
            }
            continue;
        }
        catch (...)
        {
            LOG(ERROR) << node->id.to_string() << " - Fail grabbing frame";
            m_place_manager.release_empty_frame(node->id.to_string(), frame_buffer.id);
            this_thread::sleep_for(50ms);
            bad_frames++;
            if (bad_frames > MAX_BAD_FRAMES)
            {
                LOG(ERROR) << node->id.to_string() << " - Too many bad_frames. Aborting!";
                this_thread_state = false;
                break;
            }
            continue;
        }

        bad_frames = 0;

        if (frame_buffer.frame_data.empty())
        {
            LOG(INFO) << node->id.to_string() << " - Received empty frame";
            m_place_manager.release_empty_frame(node->id.to_string(), frame_buffer.id);
            this_thread::sleep_for(50ms);
            continue;
        }

        frame_buffer.frame_data["component_input"] = "";
        frame_buffer.frame_data["component_output"] = "component_" + node->id.to_string();
        m_place_manager.update_frame(node->id.to_string(), frame_buffer.id, frame_buffer.frame_data);

        node->notify_consumers();
        // this_thread::sleep_for(1ms);
    }

    node->m_streamer->stop();
    m_place_manager.restart_place(node->id.to_string(), node->m_streamer->get_max_buffer_size());
    node->notify_consumers();
    LOG(INFO) << node->id.to_string() << " - End grabbing";
}
// --------------------------------------------------------------------------------------------------------------------------------

void FlowProcess::thd_consumer(NodeComponent* node)
{
    LOG(INFO) << "thd_consumer started PlaceName: " << node->id.to_string();

    int num_frames = 0;
    int bad_frames = 0;
    bool this_thread_state = true;
    std::vector<int> process_times;
    std::chrono::time_point<std::chrono::system_clock> last_log = std::chrono::system_clock::now();

    while (m_thread_state && this_thread_state)
    {
        std::unique_lock<std::mutex> lk(*node->m_cv_mutex);
        node->m_cvar->wait(lk, [&node]()
                                { return node->input_ready(); });

        for (auto input_it = node->m_input_list.begin(); input_it != node->m_input_list.end(); input_it++)
        {
            if (!*input_it->has_data)
                continue;

            Frame frame_buffer;
            if (m_place_manager.get_filled_frame(input_it->id.to_string(), node->id, frame_buffer) != FrameResult::FRAME_OK)
            {
                LOG(INFO) << "No frame to process";
                this_thread::sleep_for(100ms);
                break;
            }
            *input_it->has_data = false;

            try
            {
                auto start_time = std::chrono::system_clock::now();
                node->m_consumer->process_frame(frame_buffer);
                process_times.push_back(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start_time).count());
            }
            catch (std::exception &excpt)
            {
                LOG(ERROR) << node->m_consumer->get_name() << " - Fail processing frame: " << excpt.what();
                m_place_manager.release_frame(input_it->id.to_string(), frame_buffer.id, node->id, false);
                bad_frames++;
                if (bad_frames > MAX_BAD_FRAMES)
                {
                    LOG(ERROR) << node->m_consumer->get_name() << " - Too many bad_frames. Aborting!";
                    this_thread_state = false;
                    break;
                }
            }
            catch (...)
            {
                LOG(ERROR) << node->m_consumer->get_name() << " - Fail processing frame";
                m_place_manager.release_frame(input_it->id.to_string(), frame_buffer.id, node->id, false);
                bad_frames++;
                if (bad_frames > MAX_BAD_FRAMES)
                {
                    LOG(ERROR) << node->m_consumer->get_name() << " - Too many bad_frames. Aborting!";
                    this_thread_state = false;
                    break;
                }
            }

            bad_frames = 0;

            m_place_manager.release_frame(input_it->id.to_string(), frame_buffer.id, node->id, false);
        }

        lk.unlock();
        num_frames++;

        auto microseconds = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - last_log);
        if (microseconds.count() > LOG_HISTORY_TIME)
        {
            double proc_avg = (double)std::accumulate(process_times.begin(), process_times.end(), 0) / process_times.size() / 1000;
            LOG(INFO) << node->m_consumer->get_id().to_string() << "-" << node->m_consumer->get_name() << " - Frames: " << num_frames << " - Avg process time: " << proc_avg << " ms";
            last_log = std::chrono::system_clock::now();
            process_times.clear();
        }

        this_thread::sleep_for(1ms);
    }

    node->m_consumer->stop();
    LOG(INFO) << "End consuming - Frames: " << num_frames;
}
// --------------------------------------------------------------------------------------------------------------------------------

void FlowProcess::thd_processor(NodeComponent* node)
{
    LOG(INFO) << "thd_processor started PlaceName: " << node->id.to_string();

    int num_frames = 0;
    int bad_frames = 0;
    bool this_thread_state = true;
    std::vector<int> process_times;
    std::chrono::time_point<std::chrono::system_clock> last_log;

    while (m_thread_state && this_thread_state)
    {
        std::unique_lock<std::mutex> lk_input(*node->m_cv_mutex);
        node->m_cvar->wait(lk_input, [&node]()
                                { return node->input_ready(); });

        for (auto input_it = node->m_input_list.begin(); input_it != node->m_input_list.end(); input_it++)
        {
            if (!*input_it->has_data)
                continue;

            Frame input_frame_buffer;
            if (m_place_manager.get_filled_frame(input_it->id.to_string(), node->id, input_frame_buffer) != FrameResult::FRAME_OK)
                continue;

            *input_it->has_data = false;
            num_frames++;

            FrameResult result = FrameResult::FRAME_INVALID;
            std::vector<Frame> output_frames;
            try
            {
                auto start_time = std::chrono::system_clock::now();
                result = node->m_processor->process_frame(input_frame_buffer, output_frames);
                process_times.push_back(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start_time).count());
            }
            catch (std::exception &excpt)
            {
                LOG(ERROR) << node->id.to_string() << " - Fail processing frame: " << excpt.what();
            }
            catch (...)
            {
                LOG(ERROR) << node->id.to_string() << " - Fail processing frame";
            }

            m_place_manager.release_frame(input_it->id.to_string(), input_frame_buffer.id, node->id, false);

            if (result == FrameResult::FRAME_EMPTY)
            {
                for (Frame& out_frame : output_frames)
                {
                    m_place_manager.release_empty_frame(node->id.to_string(), out_frame.id);
                }

                output_frames.clear();
            }
            else if (result == FrameResult::FRAME_INVALID)
            {
                for (Frame& out_frame : output_frames)
                {
                    m_place_manager.release_empty_frame(node->id.to_string(), out_frame.id);
                }

                output_frames.clear();

                bad_frames++;
                if (bad_frames > MAX_BAD_FRAMES)
                {
                    LOG(ERROR) << node->id.to_string() << " - Too many bad_frames. Aborting!";
                    this_thread_state = false;
                }
            }
            else if (result == FrameResult::FRAME_OK)
            {
                for (Frame& out_frame : output_frames)
                {
                    if (out_frame.frame_data.empty())
                    {
                        LOG(WARNING) << node->id.to_string() << " - Received empty frame";
                        continue;
                    }

                    bad_frames = 0;
                    out_frame.frame_data["component_input"] = input_frame_buffer.frame_data["component_output"].get<std::string>();
                    out_frame.frame_data["component_output"] = "component_" + node->id.to_string();
                    m_place_manager.update_frame(node->id.to_string(), out_frame.id, out_frame.frame_data);
                    node->notify_consumers();
                }

                output_frames.clear();
            }
        }

        lk_input.unlock();

        auto microseconds = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - last_log);
        if (microseconds.count() > LOG_HISTORY_TIME)
        {
            double proc_avg = (double)std::accumulate(process_times.begin(), process_times.end(), 0) / process_times.size() / 1000;
            LOG(INFO) << node->m_processor->get_id().to_string() << "-" << node->m_processor->get_name() << " - Frames: " << num_frames << " - Avg process time: " << proc_avg << " ms";
            last_log = std::chrono::system_clock::now();
            process_times.clear();
        }

        this_thread::sleep_for(1ms);
    }

    node->m_processor->stop();
    LOG(INFO) << "End processor - Frames: " << num_frames;
}
// --------------------------------------------------------------------------------------------------------------------------------

void FlowProcess::thd_annotator(NodeComponent* node)
{
    LOG(INFO) << "thd_annotator started PlaceName: " << node->id.to_string();

    int no_frames = 0;
    int num_frames = 0;
    int bad_frames = 0;
    bool this_thread_state = true;
    std::vector<int> process_times;
    std::chrono::time_point<std::chrono::system_clock> last_log;

    while (m_thread_state && this_thread_state)
    {
        std::unique_lock<std::mutex> lk_input(*node->m_cv_mutex);
        node->m_cvar->wait(lk_input, [&node]()
                                { return node->input_ready(); });

        for (auto input_it = node->m_input_list.begin(); input_it != node->m_input_list.end(); input_it++)
        {
            if (!*input_it->has_data)
                continue;

            Frame input_frame_buffer;
            if (m_place_manager.get_filled_frame(input_it->id.to_string(), node->id, input_frame_buffer) != FrameResult::FRAME_OK)
                continue;

            *input_it->has_data = false;
            num_frames++;

            Frame output_frame_buffer;
            if (m_place_manager.get_empty_frame(node->id.to_string(), input_frame_buffer.mem_buffer.buffer_size, output_frame_buffer) != FrameResult::FRAME_OK)
            {
                m_place_manager.release_frame(input_it->id.to_string(), input_frame_buffer.id, node->id, false);
                no_frames++;
                if (no_frames > MAX_BAD_FRAMES)
                {
                    LOG(ERROR) << node->id.to_string() << " - Fail in sync threads. Aborting!";
                    this_thread_state = false;
                }
                break;
            }

            no_frames = 0;

            FrameResult result = FrameResult::FRAME_INVALID;
            try
            {
                auto start_time = std::chrono::system_clock::now();
                result = node->m_annotator->process_frame(input_frame_buffer, output_frame_buffer.frame_data);
                process_times.push_back(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - start_time).count());
            }
            catch (std::exception &excpt)
            {
                LOG(ERROR) << node->id.to_string() << " - Fail processing frame: " << excpt.what();
            }
            catch (...)
            {
                LOG(ERROR) << node->id.to_string() << " - Fail processing frame";
            }

            m_place_manager.release_frame(input_it->id.to_string(), input_frame_buffer.id, node->id, false);

            if (result == FrameResult::FRAME_EMPTY)
            {
                m_place_manager.release_empty_frame(node->id.to_string(), output_frame_buffer.id);
            }
            else if (result == FrameResult::FRAME_INVALID)
            {
                m_place_manager.release_empty_frame(node->id.to_string(), output_frame_buffer.id);

                bad_frames++;
                if (bad_frames > MAX_BAD_FRAMES)
                {
                    LOG(ERROR) << node->id.to_string() << " - Too many bad_frames. Aborting!";
                    this_thread_state = false;
                }
            }
            else if (result == FrameResult::FRAME_OK)
            {
                if (output_frame_buffer.frame_data.empty())
                {
                    LOG(WARNING) << node->id.to_string() << " - Received empty frame";
                    continue;
                }

                bad_frames = 0;
                memcpy(output_frame_buffer.mem_buffer.buf_ptr, input_frame_buffer.mem_buffer.buf_ptr, input_frame_buffer.mem_buffer.buffer_size);
                output_frame_buffer.frame_data["component_input"] = input_frame_buffer.frame_data["component_output"].get<std::string>();
                output_frame_buffer.frame_data["component_output"] = "component_" + node->id.to_string();
                m_place_manager.update_frame(node->id.to_string(), output_frame_buffer.id, output_frame_buffer.frame_data);
                node->notify_consumers();
            }
        }

        lk_input.unlock();

        auto microseconds = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now() - last_log);
        if (microseconds.count() > LOG_HISTORY_TIME)
        {
            double proc_avg = (double)std::accumulate(process_times.begin(), process_times.end(), 0) / process_times.size() / 1000;
            LOG(INFO) << node->m_annotator->get_id().to_string() << "-" << node->m_annotator->get_name() << " - Frames: " << num_frames << " - Avg process time: " << proc_avg << " ms";
            last_log = std::chrono::system_clock::now();
            process_times.clear();
        }

        this_thread::sleep_for(1ms);
    }

    node->m_annotator->stop();
    LOG(INFO) << "End annotator - Frames: " << num_frames;
}
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
