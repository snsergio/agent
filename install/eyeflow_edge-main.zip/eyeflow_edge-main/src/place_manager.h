#pragma once

#include <string>
#include <vector>
#include <map>
#include <chrono>
#include <mutex>
#include <shared_mutex>

#include <nlohmann/json.hpp>
using json = nlohmann::json;

#include <bsoncxx/oid.hpp>

#define MAX_BAD_FRAMES 200

#include "frame.h"
// --------------------------------------------------------------------------------------------------------------------------------

enum class FrameState
{
    EMPTY,
    ALLOCATED,
    FILLED,
    LINKED
};

struct Subscriber
{
    bsoncxx::oid id;
    std::string name;
    FrameState state;
    std::chrono::time_point<std::chrono::system_clock> lease_time;
};

struct FrameBuf
{
    Frame frame;
    std::chrono::time_point<std::chrono::system_clock> lease_time;
    FrameState state;
    std::vector<Subscriber> subscriber_list;
};
// --------------------------------------------------------------------------------------------------------------------------------

class Placeholder
{
public:
    Placeholder(std::string place_id, std::string place_name, int buffer_max_size, int max_num_buffers);
    Placeholder(Placeholder&& other);
    ~Placeholder();

    void restart_place(int buffer_size);
    FrameResult get_empty_frame(int buffer_size, Frame& ret_frame);
    void release_empty_frame(FrameHandle frame_id);
    void update_frame(FrameHandle frame_id, json frame_data);
    FrameResult get_filled_frame(bsoncxx::oid subscriber_id, Frame& ret_frame);
    void release_frame(FrameHandle frame_id, bsoncxx::oid subscriber_id, bool linked);
    void add_subscriber(bsoncxx::oid subscriber_id, std::string subscriber_name);

    void log_history(int microseconds);

private:
    std::string m_place_id;
    std::string m_place_name;
    int m_buffer_max_size;
    int m_max_num_buffers;
    std::map<FrameHandle, FrameBuf> m_buffer_map;
    std::vector<Subscriber> m_subscribers;

    std::shared_ptr<std::mutex> m_place_mutex;

    int m_filled_frames;
    int m_consumed_frames;
    int m_dropped_frames;

    FrameHandle create_new_buffer(int buffer_size);
};
// --------------------------------------------------------------------------------------------------------------------------------

class PlaceManager
{
public:
    PlaceManager(int max_frames);
    ~PlaceManager() = default;

    void create_new_place(std::string place_id, std::string place_name, int buffer_size, int max_num_buffers);
    void restart_place(std::string place_id, int buffer_size);

    FrameResult get_empty_frame(std::string place_id, int buffer_size, Frame& ret_frame);
    void release_empty_frame(std::string place_id, FrameHandle frame_id);
    void update_frame(std::string place_id, FrameHandle frame_id, json frame_data);
    FrameResult get_filled_frame(std::string place_id, bsoncxx::oid subscriber_id, Frame& ret_frame);
    void release_frame(std::string place_id, FrameHandle frame_id, bsoncxx::oid subscriber_id, bool linked);
    void add_subscriber(std::string place_id, bsoncxx::oid subscriber_id, std::string subscriber_name);

    void log_history(int microseconds);

private:
    int m_max_frames;
    std::map<std::string, Placeholder> m_placeholders;
    mutable std::shared_timed_mutex m_map_mutex;
};
// --------------------------------------------------------------------------------------------------------------------------------
