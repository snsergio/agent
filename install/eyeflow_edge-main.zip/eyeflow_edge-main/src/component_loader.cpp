#include <dlfcn.h>

#include <glog/logging.h>

#include <filesystem>
namespace fs = std::filesystem;

#include "component_loader.h"

#include "video_window/video_window.h"
#include "video_save/video_save.h"
#include "frame_data_save/frame_data_save.h"
#include "video_test/video_test.h"
#include "image_test/image_test.h"
#include "input_endpoint/input_endpoint.h"

#include <nlohmann/json.hpp>
using json = nlohmann::json;
extern json g_eyeflow_conf;
// --------------------------------------------------------------------------------------------------------------------------------

ComponentLib ComponentLoader::get_component_lib(json component_node)
{
    if (!component_node.contains("component_id"))
        throw std::runtime_error("Component has not 'component_id'");

    if (!component_node.contains("component_name"))
        throw std::runtime_error("Component has not 'component_name'");

    std::string component_id = component_node["component_id"].get<std::string>();

    if (component_libs.find(component_id) == component_libs.end())
    {
        ComponentLib comp_lib;
        comp_lib.component_id = component_node["component_id"].get<std::string>();
        comp_lib.component_name = component_node["component_name"].get<std::string>();

        fs::path comp_path(g_eyeflow_conf["file-service"]["components"].get<std::string>());
        std::string comp_lib_file = "libedge_comp-" + comp_lib.component_name + ".so";
        comp_path.append(comp_lib.component_id);
        comp_path.append(comp_lib_file);

        if (!fs::exists(comp_path))
            throw std::runtime_error("Component library not found: " + comp_path.string());

        LOG(INFO) << "Loading component lib: " << comp_lib_file;
        comp_lib.lib_handler = dlopen(comp_path.c_str(), RTLD_NOW);
        if (!comp_lib.lib_handler)
        {
            LOG(ERROR) << "Error loading component lib: " << comp_path << " - " << dlerror();
            throw std::runtime_error(dlerror());
        }

        component_libs.insert({component_id, comp_lib});
    }

    return component_libs[component_id];
}
// --------------------------------------------------------------------------------------------------------------------------------

// ComponentLoader::~ComponentLoader()
// {
    // if (handler)
    //     dlclose(handler);
// }
// --------------------------------------------------------------------------------------------------------------------------------

void ComponentLoader::reset_dlerror()
{
    dlerror();
}
// --------------------------------------------------------------------------------------------------------------------------------

void ComponentLoader::check_dlerror()
{
    const char * dlsym_error = dlerror();
    if (dlsym_error)
        throw std::runtime_error(dlsym_error);
}
// --------------------------------------------------------------------------------------------------------------------------------

std::shared_ptr<FrameStreamer> ComponentLoader::load_component_streamer(json component_node)
{
    try
    {
        std::string component_name = component_node["options"]["component"].get<std::string>();
        LOG(INFO) << "Load Component: " << component_name;

        if (component_name == "video_test")
        {
            std::shared_ptr<FrameStreamer> streamer = std::make_shared<video_test::Component>(component_node);
            return streamer;
        }
        else if (component_name == "image_test")
        {
            std::shared_ptr<FrameStreamer> streamer = std::make_shared<image_test::Component>(component_node);
            return streamer;
        }
        else
        {
            ComponentLib comp_lib = get_component_lib(component_node);
            reset_dlerror();
            frame_streamer_creator_t creator = reinterpret_cast<frame_streamer_creator_t>(dlsym(comp_lib.lib_handler, "create"));
            check_dlerror();
            return std::shared_ptr<FrameStreamer>(creator(component_node));
        }
    }
    catch (std::exception &excpt)
    {
        LOG(ERROR) << "Fail loading component: " << excpt.what();
        throw excpt;
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

std::shared_ptr<FrameEvent> ComponentLoader::load_component_event(json component_node)
{
    try
    {
        std::string component_name = component_node["options"]["component"].get<std::string>();
        LOG(INFO) << "Load Component: " << component_name;

        ComponentLib comp_lib = get_component_lib(component_node);
        reset_dlerror();
        frame_event_creator_t creator = reinterpret_cast<frame_event_creator_t>(dlsym(comp_lib.lib_handler, "create"));
        check_dlerror();
        return std::shared_ptr<FrameEvent>(creator(component_node));
    }
    catch (std::exception &excpt)
    {
        LOG(ERROR) << "Fail loading component: " << excpt.what();
        throw excpt;
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

std::shared_ptr<FrameConsumer> ComponentLoader::load_component_consumer(json component_node)
{
    try
    {
        std::string component_name = component_node["options"]["component"].get<std::string>();
        LOG(INFO) << "Load Component: " << component_name;

        if (component_name == "video_window")
        {
            std::shared_ptr<FrameConsumer> consumer = std::make_shared<video_window::Component>(component_node);
            return consumer;
        }
        else if (component_name == "video_save")
        {
            std::shared_ptr<FrameConsumer> consumer = std::make_shared<video_save::Component>(component_node);
            return consumer;
        }
        else if (component_name == "frame_data_save")
        {
            std::shared_ptr<FrameConsumer> consumer = std::make_shared<frame_data_save::Component>(component_node);
            return consumer;
        }
        else
        {
            ComponentLib comp_lib = get_component_lib(component_node);
            reset_dlerror();
            frame_consumer_creator_t creator = reinterpret_cast<frame_consumer_creator_t>(dlsym(comp_lib.lib_handler, "create"));
            check_dlerror();
            return std::shared_ptr<FrameConsumer>(creator(component_node));
        }
    }
    catch (std::exception &excpt)
    {
        LOG(ERROR) << "Fail loading component: " << excpt.what();
        throw excpt;
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

std::shared_ptr<FrameProcessor> ComponentLoader::load_component_processor(json component_node)
{
    try
    {
        std::string component_name = component_node["options"]["component"].get<std::string>();
        LOG(INFO) << "Load Component: " << component_name;

        ComponentLib comp_lib = get_component_lib(component_node);
        reset_dlerror();
        frame_processor_creator_t creator = reinterpret_cast<frame_processor_creator_t>(dlsym(comp_lib.lib_handler, "create"));
        check_dlerror();
        return std::shared_ptr<FrameProcessor>(creator(component_node));
    }
    catch (std::exception &excpt)
    {
        LOG(ERROR) << "Fail loading component: " << excpt.what();
        throw excpt;
    }
}
// --------------------------------------------------------------------------------------------------------------------------------

std::shared_ptr<FrameAnnotator> ComponentLoader::load_component_annotator(json component_node)
{
    try
    {
        std::string component_name = component_node["options"]["component"].get<std::string>();
        LOG(INFO) << "Load Component: " << component_name;

        ComponentLib comp_lib = get_component_lib(component_node);
        reset_dlerror();
        frame_annotator_creator_t creator = reinterpret_cast<frame_annotator_creator_t>(dlsym(comp_lib.lib_handler, "create"));
        check_dlerror();
        return std::shared_ptr<FrameAnnotator>(creator(component_node));
    }
    catch (std::exception &excpt)
    {
        LOG(ERROR) << "Fail loading component: " << excpt.what();
        throw excpt;
    }
}
// --------------------------------------------------------------------------------------------------------------------------------
