# from codecs import encode
import os
import sys
import json
import datetime
import numpy as np

from eyeflow_sdk.log_obj import log

os.environ["CUDA_MODULE_LOADING"] = "LAZY"

with open(os.path.join(os.path.dirname(__file__), "eyeflow_conf.json")) as fp:
    LOCAL_CONFIG = json.load(fp)

import onnx
import onnx_graphsurgeon as gs
import tensorrt as trt
#----------------------------------------------------------------------------------------------------------------------------------


def create_NMS_engine(model_props, engine_path, output_boxes, output_classes, precision):
    trt_logger = trt.Logger(min_severity=trt.Logger.INFO)

    if precision == "fp32":
        np_pecision = np.float32
    elif precision == "fp16":
        np_pecision = np.float16

    # NMS Inputs.
    nms_input_classification = gs.Variable(
        name="input_classification",
        dtype=np_pecision,
        shape=[-1, -1, output_classes]
    )

    nms_input_boxes = gs.Variable(
        name="input_boxes",
        dtype=np_pecision,
        shape=[-1, -1, 4]
    )

    # NMS Outputs.
    nms_output_num_detections = gs.Variable(
        name="num_detections",
        dtype=np.int32,
        shape=[-1, 1]
    )

    nms_output_boxes = gs.Variable(
        name="detection_boxes",
        dtype=np_pecision,
        shape=[-1, model_props["max_boxes"], 4]
    )

    nms_output_scores = gs.Variable(
        name="detection_scores",
        dtype=np_pecision,
        shape=[-1, model_props["max_boxes"]]
    )

    nms_output_classes = gs.Variable(
        name="detection_classes",
        dtype=np.int32,
        shape=[-1, model_props["max_boxes"]]
    )

    nms_inputs = [nms_input_boxes, nms_input_classification]
    nms_outputs = [nms_output_num_detections, nms_output_boxes, nms_output_scores, nms_output_classes]

    # Plugin.
    nms_node = gs.Node(
        op="EfficientNMS_TRT",
        name="nms/non_maximum_suppression",
        inputs=nms_inputs,
        outputs=nms_outputs,
        attrs={
            'plugin_version': "1",
            'background_class': -1,
            'max_output_boxes': int(model_props["max_boxes"]),
            'score_threshold': max(0.01, float(model_props["confidence_threshold"])),
            'iou_threshold': float(model_props["nms_iou_threshold"]),
            'score_activation': False,
            'box_coding': 0
        }
    )

    graph_nms = gs.Graph(nodes=[nms_node], inputs=nms_inputs, outputs=nms_outputs, opset=13)
    graph_nms.cleanup().toposort()
    onnx_nms_model = gs.export_onnx(graph_nms)
    log.info("Created 'nms/non_maximum_suppression' NMS plugin")

    trt.init_libnvinfer_plugins(trt_logger, namespace="")

    builder = trt.Builder(trt_logger)
    config = builder.create_builder_config()

    config.max_workspace_size = 4 * (2 ** 30)

    network_flags = (1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))

    network = builder.create_network(network_flags)
    parser = trt.OnnxParser(network, trt_logger)

    if not parser.parse(onnx_nms_model.SerializeToString()):
        log.error("Failed to parse ONNX NMS model")
        for error in range(parser.num_errors):
            log.error(parser.get_error(error))
        sys.exit(1)

    inputs = [network.get_input(i) for i in range(network.num_inputs)]
    outputs = [network.get_output(i) for i in range(network.num_outputs)]

    log.info("Network Description")
    for input in inputs:
        log.info("Input '{}' with shape {} and dtype {}".format(input.name, input.shape, input.dtype))
    for output in outputs:
        log.info("Output '{}' with shape {} and dtype {}".format(output.name, output.shape, output.dtype))

    engine_path = os.path.realpath(engine_path)
    engine_dir = os.path.dirname(engine_path)
    os.makedirs(engine_dir, exist_ok=True)
    log.info(f"Building {precision} Engine in {engine_path}")

    if precision == "fp16":
        if not builder.platform_has_fast_fp16:
            log.warning("FP16 is not supported natively on this platform/device")
        else:
            config.set_flag(trt.BuilderFlag.FP16)
    elif precision == "int8":
        raise Exception("INT8 is not supported natively on this platform/device")

    builder.max_batch_size = 1 # min(128, int(model_props["max_num_patches_frame"]))
    max_output_boxes = int(int(model_props["max_num_patches_frame"]) * 0.75) * output_boxes
    profile = builder.create_optimization_profile()

    profile.set_shape('input_boxes', (1, output_boxes, 4), (1, max_output_boxes // 2, 4), (1, max_output_boxes, 4))
    profile.set_shape('input_classification', (1, output_boxes, output_classes), (1, max_output_boxes // 2, output_classes), (1, max_output_boxes, output_classes))

    config.add_optimization_profile(profile)

    serialized_engine = builder.build_serialized_network(network, config)
    with open(engine_path, "wb") as f:
        log.info("Serializing engine to file: {:}".format(engine_path))
        f.write(serialized_engine)

    return
# ---------------------------------------------------------------------------------------------------------------------------------


def convert_model_trt(onnx_file, trt_file, component_options, precision="fp32"):
    """
    Parses an ONNX graph and builds a TensorRT engine from it.
    """

    onnx_file_date = os.path.getmtime(onnx_file)
    if os.path.isfile(trt_file):
        engine_file_date = os.path.getmtime(trt_file)

    if os.path.isfile(trt_file) and onnx_file_date < engine_file_date:
        return

    log.info(f"Converting Model {onnx_file} to TensorRT")

    trt_logger = trt.Logger(min_severity=trt.Logger.INFO)

    trt.init_libnvinfer_plugins(trt_logger, namespace="")

    builder = trt.Builder(trt_logger)
    config = builder.create_builder_config()

    config.max_workspace_size = 4 * (2 ** 30) # 4 GB

    with open(onnx_file, "rb") as fp:
        onnx_model = onnx.load(fp)

    model_props = {}

    model_props["model_version"] = onnx_model.model_version
    model_props["producer_name"] = onnx_model.producer_name
    model_props["producer_version"] = onnx_model.producer_version
    model_props["doc_string"] = onnx_model.doc_string

    log.info(f'Model Version: {model_props["model_version"]}')
    log.info(f'Producer Name: {model_props["producer_name"]}')
    log.info(f'Producer Version: {model_props["producer_version"]}')
    log.info(f'Doc String: {model_props["doc_string"]}')

    for t in onnx_model.metadata_props:
        log.info(f"{t.key}: {t.value}")
        model_props[t.key] = t.value

    props_file = trt_file[:-4] + "_props.json"
    with open(props_file, "w") as f:
        log.info(f"Serializing props to file: {props_file}")
        json.dump(model_props, f)

    network_flags = (1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH))

    network = builder.create_network(network_flags)
    parser = trt.OnnxParser(network, trt_logger)

    onnx_path = os.path.realpath(onnx_file)
    with open(onnx_path, "rb") as f:
        if not parser.parse(f.read()):
            log.error(f"Failed to load ONNX file: {onnx_path}")
            for error in range(parser.num_errors):
                log.error(parser.get_error(error))
            raise

    inputs = [network.get_input(i) for i in range(network.num_inputs)]
    outputs = [network.get_output(i) for i in range(network.num_outputs)]

    log.info("Network Description")
    for input in inputs:
        log.info("Input '{}' with shape {} and dtype {}".format(input.name, input.shape, input.dtype))
    for output in outputs:
        log.info("Output '{}' with shape {} and dtype {}".format(output.name, output.shape, output.dtype))

    trt_file = os.path.realpath(trt_file)
    engine_dir = os.path.dirname(trt_file)
    os.makedirs(engine_dir, exist_ok=True)

    log.info(f"Building {precision} Engine in {trt_file}")

    if precision == "fp16":
        if not builder.platform_has_fast_fp16:
            log.warning("FP16 is not supported natively on this platform/device")
        else:
            config.set_flag(trt.BuilderFlag.FP16)
    elif precision == "int8":
        # if not builder.platform_has_fast_int8:
        raise Exception("INT8 is not supported natively on this platform/device")

    builder.max_batch_size = int(model_props.get("max_num_patches_frame", 2))
    profile = builder.create_optimization_profile()

    if network.num_inputs != 1:
        raise Exception(f"Invalid num of inputs: {network.num_inputs}")

    optmized_shapes = [1, 1, 1]
    if model_props["dataset_type"] == "object_location":
        optmized_shapes = [1, int(model_props.get("max_num_patches_frame", 2)) // 2, int(model_props.get("max_num_patches_frame", 2))]

    input_shape = network.get_input(0).shape
    profile.set_shape(
        'input',
        (optmized_shapes[0], input_shape[1], input_shape[2], input_shape[3]),
        (optmized_shapes[1], input_shape[1], input_shape[2], input_shape[3]),
        (optmized_shapes[2], input_shape[1], input_shape[2], input_shape[3])
    )

    config.add_optimization_profile(profile)

    serialized_engine = builder.build_serialized_network(network, config)
    with open(trt_file, "wb") as f:
        log.info(f"Serializing engine to file: {trt_file}")
        f.write(serialized_engine)

    if model_props["dataset_type"] == "object_location":
        trt_nms_file = trt_file[:-4] + "_nms.trt"

        if "detection_confidence" in component_options:
            model_props["confidence_threshold"] = component_options["detection_confidence"]
        else:
            model_props["confidence_threshold"] = float(model_props["confidence_threshold"])

        if "nms_iou_thresh" in component_options:
            model_props["nms_iou_threshold"] = component_options["nms_iou_thresh"]
        else:
            model_props["nms_iou_threshold"] = float(model_props["nms_iou_threshold"])

        create_NMS_engine(
            model_props=model_props,
            engine_path=trt_nms_file,
            output_boxes=network.get_output(0).shape[1],
            output_classes=network.get_output(1).shape[2],
            precision=precision
        )
# ---------------------------------------------------------------------------------------------------------------------------------


def main(args=None):
    try:
        edge_data_filename = LOCAL_CONFIG["file-service"]["data_folder"] + "/edge_data.json"
        with open(edge_data_filename) as fp:
            edge_data = json.load(fp)

        log.info(f'EyeflowEdge: {edge_data["edge_data"]["name"]} - {edge_data["edge_data"]["_id"]}')
        log.info(f'Running Flow: {edge_data["edge_data"]["flow_name"]} - {edge_data["edge_data"]["flow_id"]} - Last modified: {edge_data["edge_data"]["flow_modified_date"]}')

        flow_id = edge_data["edge_data"]["flow_id"]
        flow_data_filename = LOCAL_CONFIG["file-service"]["flow"] + f"/{flow_id}.json"
        with open(flow_data_filename) as fp:
            flow_data = json.load(fp)

        if not flow_data:
            log.error(f"Fail getting flow from local backup. Need to connect to cloud.")
            exit(1)

        log.info(f"Prepare datasets for flow")

        datasets_downloaded = []
        for comp in flow_data["nodes"]:
            if "dataset_id" in comp["options"]:
                dataset_id = comp["options"]["dataset_id"]
                if dataset_id not in datasets_downloaded:
                    datasets_downloaded.append(dataset_id)
                    model_folder = LOCAL_CONFIG["file-service"]["model"]
                    onnx_file = os.path.join(model_folder, dataset_id + ".onnx")
                    info_file = os.path.join(model_folder, dataset_id + ".json")
                    trt_file = os.path.join(model_folder, dataset_id + ".trt")

                    if not os.path.isfile(onnx_file):
                        raise Exception(f'Model for dataset {dataset_id} not found at: {onnx_file}')

                    onnx_stat = os.stat(onnx_file)
                    onnx_date = datetime.datetime.fromtimestamp(onnx_stat.st_mtime, datetime.timezone.utc)

                    if not os.path.isfile(trt_file):
                        convert_model_trt(onnx_file, trt_file, comp["options"])
                    else:
                        trt_stat = os.stat(trt_file)
                        trt_date = datetime.datetime.fromtimestamp(trt_stat.st_mtime, datetime.timezone.utc)
                        if trt_date < onnx_date:
                            convert_model_trt(onnx_file, trt_file, comp["options"])

    except Exception as expt:
        log.error(f'Fail preparing models {expt}')
        exit(1)
#----------------------------------------------------------------------------------------------------------------------------------

# convert_model_trt("/data/eyeflow/data/models/63d9645c96194f001b5a7a09.onnx", "/data/eyeflow/data/models/63d9645c96194f001b5a7a09.trt", {"detection_confidence": 0.5})
main()
