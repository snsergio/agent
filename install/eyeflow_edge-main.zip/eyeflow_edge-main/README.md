# eyeflow_edge
Product repo for Eyeflow Edge

## Compilação

Clonar o repositório para a máquina de desenvolvimento e abrir no VSCode

```/projs/eyeflow_edge```

Criar um container de desenvolvimento para compilação

Baixar a imagem docker caso não exista ainda na máquina. (obs: É necessário estar logado na Azure com ```az login```)
```
az acr login -n eyeflow
docker pull eyeflow.azurecr.io/eyeflow_dev
```
Navegar até o diretório 'container' e executar o script

```
cd /projs/eyeflow_edge/container
./run_dev_container.sh
```

Esse comando irá criar um container que será o ambiente de dev/compilação com o nome do usuário. Esse container ficará ativo enquanto estiver logado. Quando sair com 'exit' ele ficará desligado. Será possível acessá-lo novamente diretamente pelo Remote Explorer.
```
docker ps -a
CONTAINER ID   IMAGE                            COMMAND                  CREATED              STATUS              PORTS     NAMES
41511b16c1c3   eyeflow.azurecr.io/eyeflow_dev   "/opt/nvidia/nvidia_…"   About a minute ago   Up About a minute             alexsobral_eyeflow_edge_dev
```
No VSCode vá no 'Remote Explorer' / 'Containers' e escolha para se conectar com o seu container 'Attach to Container'.
Instale suas extensões no container, especialmente o CMake, CMake Tools e o C/C++ Extension Pack.

Clone o repositório do eyeflow_edge no seu container na pasta ```/home``` e abra no VSCode.

Confirme que o CMake encontrou todas as bibliotecas e já está pronto para compilar.

Após a copilação, navegue no prompt do container até a pasta container e confirme que essa pasta é a do seu host mapeada no container. Daí é só rodar o script.
```
cd /home/container
python3 prepare_runtime.py /home/eyeflow_edge
```
Neste ponto na pasta do host vão aparecer dois diretórios 'run' e 'lib' com o código compilado e as bibliotecas. Esses arquivos serão usados para montar o docker runtime.

Agora de dentro da pasta container do host basta executar o script para criar e fazer push da imagem de runtime.
```
./build_runtime.sh
```
O script irá ao final fazer o push da imagem para o docker hub, e precisará estar logado para ter sucesso.

## Runtime
Para execução na máquina edge é necessário:
- Driver NVIDIA versão min: 525
- Docker
- NVIDIA Docker - https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html
- Imagem eyeflow_edge do Docker Hub
- Conteúdo da pasta 'run' do repositório

Todos esses passos estão no script ```install_edge.sh``` que está na pasta 'run'

O comando para executar a edge é ```edge_run```, o script está no repositório na pasta "run".

Para que o edge possa acessar as câmeras são necessárias configurações específicas mapeando a rede ou as USBs do host para o container.

Ex: opções para acessar câmeras FLIR
```
--volume /opt/spinnaker:/opt/spinnaker \
--env FLIR_GENTL64_CTI=/opt/spinnaker/lib/flir-gentl/FLIR_GenTL.cti \
--device=/dev/bus/usb/002/002 \
```
