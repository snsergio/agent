sudo cp /opt/eyeflow/install/run_flow.service /etc/systemd/system/.
sudo systemctl enable --now run_flow.service
