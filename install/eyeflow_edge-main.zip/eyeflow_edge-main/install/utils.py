# from codecs import encode
import os
import platform
import socket
import uuid
import json
import jwt
import requests
import datetime
import tarfile
from pathlib import Path

from eyeflow_sdk.log_obj import log
from eyeflow_sdk import jetson_utils
from eyeflow_sdk import edge_client

os.environ["CUDA_MODULE_LOADING"] = "LAZY"

with open(os.path.join(os.path.dirname(__file__), "../run/", "eyeflow_conf.json")) as fp:
    LOCAL_CONFIG = json.load(fp)
#----------------------------------------------------------------------------------------------------------------------------------


def download_file(url, local_filename):
    os.makedirs(os.path.dirname(local_filename), exist_ok=True)
    with requests.get(url, stream=True) as r:
        r.raise_for_status()

        if os.path.isfile(local_filename):
            os.remove(local_filename)

        with open(local_filename, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                # If you have chunk encoded response uncomment 'if' and set chunk_size parameter to None.
                #if chunk:
                f.write(chunk)
# ---------------------------------------------------------------------------------------------------------------------------------


def download_pack(app_token, pack, pack_folder):
    try:
        arch = get_device_arch()
        log.info(f'Download pack {pack["name"]}-{arch}')

        folder_path = Path(pack_folder)
        if not folder_path.is_dir():
            folder_path.mkdir(parents=True, exist_ok=True)

        endpoint = jwt.decode(app_token, options={"verify_signature": False})['endpoint']
        url = f'{endpoint}/pack/{pack["id"]}/arch/{arch}/?version={pack["version"]}'
        msg_headers = {'Authorization' : f'Bearer {app_token}'}
        payload = {"download_url": True}
        response = requests.get(url, headers=msg_headers, params=payload)

        if response.status_code != 200:
            log.error(f'Failing downloading pack {pack["name"]}: {response.json()}')
            return None, None

        pack_doc = response.json()
        dest_filename = os.path.join(folder_path, pack_doc["filename"])
        download_file(pack_doc["download_url"], dest_filename)
        return pack_doc, dest_filename

    except requests.ConnectionError as error:
        log.error(f'Failing downloading pack: {pack["name"]}. Connection error: {error}')
        return None, None
    except requests.Timeout as error:
        log.error(f'Failing downloading pack: {pack["name"]}. Timeout: {error}')
        return None, None
    except Exception as excp:
        log.error(f'Failing downloading pack: {pack["name"]} - {excp}')
        return None, None
# ---------------------------------------------------------------------------------------------------------------------------------


def get_pack(app_token, pack):
    try:
        arch = get_device_arch()
        # log.info(f'Get pack {pack["name"]}-{arch}')

        endpoint = jwt.decode(app_token, options={"verify_signature": False})['endpoint']
        url = f'{endpoint}/pack/{pack["id"]}/arch/{arch}/'
        msg_headers = {'Authorization' : f'Bearer {app_token}'}
        payload = {"download_url": False}
        response = requests.get(url, headers=msg_headers, params=payload)

        if response.status_code != 200:
            log.error(f'Failing in get pack {pack["name"]}: {response.json()}')
            return None

        return response.json()

    except requests.ConnectionError as error:
        log.error(f'Failing in get pack: {pack["name"]}. Connection error: {error}')
        return None
    except requests.Timeout as error:
        log.error(f'Failing in get pack: {pack["name"]}. Timeout: {error}')
        return None
    except Exception as excp:
        log.error(f'Failing in get pack: {pack["name"]} - {excp}')
        return None
# ---------------------------------------------------------------------------------------------------------------------------------


def update_models(app_token, flow_data):
    """
    Update models for processing flow
    """

    # log.info(f"Update models for flow")

    datasets_downloaded = []
    for comp in flow_data["nodes"]:
        if "dataset_id" in comp["options"]:
            dataset_id = comp["options"]["dataset_id"]
            if dataset_id not in datasets_downloaded:
                datasets_downloaded.append(dataset_id)
                model_folder = LOCAL_CONFIG["file-service"]["model"]
                model_file = os.path.join(model_folder, dataset_id + ".onnx")
                info_file = os.path.join(model_folder, dataset_id + ".json")
                if os.path.isfile(info_file) and not os.path.isfile(model_file):
                    os.remove(info_file)

                edge_client.get_model(app_token, dataset_id, model_folder=model_folder, model_type="onnx")
                if not os.path.isfile(model_file):
                    raise Exception(f'Model for dataset {dataset_id} not found at: {model_file}')
#----------------------------------------------------------------------------------------------------------------------------------


def update_components(app_token, flow_data):
    """
    Update components for processing flow
    """

    # log.info(f"Update components for flow")

    component_folder = LOCAL_CONFIG["file-service"]["components"]
    os.makedirs(component_folder, exist_ok=True)
    components_checked = []
    for comp in flow_data["nodes"]:
        if comp["component_id"] in components_checked:
            continue

        pack_file = os.path.join(component_folder, comp["component_id"] + ".json")
        pack_local_doc = None
        if os.path.isfile(pack_file):
            with open(pack_file) as fp:
                pack_local_doc = json.load(fp)

        try:
            pack_cloud_doc = None
            pack_cloud_doc = get_pack(app_token, {"name": comp["component_name"], "id": comp["component_id"]})
        except:
            pass

        if pack_cloud_doc is not None:
            if pack_local_doc is None or \
                (pack_local_doc is not None and datetime.datetime.strptime(pack_cloud_doc["filedate"], "%Y-%m-%dT%H:%M:%S.%f%z") > datetime.datetime.strptime(pack_local_doc["filedate"], "%Y-%m-%dT%H:%M:%S.%f%z")):
                log.info(f'Updating component: {comp["component_name"]} - {comp["component_id"]} - version: {pack_cloud_doc["version"]}')
                pack_doc, pack_filename = download_pack(app_token,
                                                        {"name": comp["component_name"], "id": comp["component_id"], "version": pack_cloud_doc["version"]},
                                                        pack_folder=LOCAL_CONFIG["file-service"]["temp_folder"]
                                                        )

                with open(pack_file, 'w') as fp:
                    json.dump(pack_doc, fp, default=str)

                component_dest = os.path.join(component_folder, comp["component_id"])
                with tarfile.open(pack_filename, 'r') as tar:
                    tar.extractall(component_dest)

        elif pack_cloud_doc is None and pack_local_doc is None:
            raise Exception(f'Fail getting component {comp["component_name"]}-{comp["component_id"]}')

        components_checked.append(comp["component_id"])
#----------------------------------------------------------------------------------------------------------------------------------


def upload_flow_extracts(app_token, flow_data, max_examples=400):
    """
    Upload extracts to datasets after processing video
    """

    log.info(f"Upload extracts for flow")

    datasets_uploaded = []
    for comp in flow_data["nodes"]:
        if "dataset_id" in comp["options"] and comp["options"]["dataset_id"] not in datasets_uploaded:
            dataset_id = comp["options"]["dataset_id"]
            datasets_uploaded.append(dataset_id)
            extract_path = os.path.join(LOCAL_CONFIG["file-service"]["extract"], dataset_id)
            files_uploaded = os.listdir(extract_path)
            if not edge_client.upload_extract(
                app_token,
                dataset_id,
                extract_folder=LOCAL_CONFIG["file-service"]["extract"],
                max_files=max_examples,
                thumb_size=128
            ):
                log.error(f'Fail uploading extract {dataset_id}')

            log.info("Deleting files from: " + extract_path)
            for filename in files_uploaded:
                os.remove(os.path.join(extract_path, filename))
#----------------------------------------------------------------------------------------------------------------------------------


def get_license(filename="edge.license"):
    # read app_token
    license_file = os.path.join(LOCAL_CONFIG["file-service"]["run_folder"], filename)
    if not os.path.isfile(license_file):
        log.error(f'Error: license_file not found {license_file}')
        raise Exception(f'Error: license_file not found {license_file}')

    with open(license_file, 'r') as fp:
        app_token = fp.read()

    key_file = os.path.join(LOCAL_CONFIG["file-service"]["run_folder"], "edge-key.pub")
    if not os.path.isfile(key_file):
        log.error(f'Error: token pub key not found {key_file}')
        raise Exception(f'Error: token pub key not found {key_file}')

    with open(key_file) as fp:
        public_key = fp.read()

    app_info = jwt.decode(app_token, public_key, algorithms=['RS256'])
    return app_info, app_token
#----------------------------------------------------------------------------------------------------------------------------------


def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP
#----------------------------------------------------------------------------------------------------------------------------------


def get_device_sn():
    try:
        filename = "/sys/class/dmi/id/product_uuid"
        if os.path.isfile(filename):
            with open(filename, 'r') as fp:
                device_id = fp.readline()

            return device_id.rstrip()
    except:
        return None
#----------------------------------------------------------------------------------------------------------------------------------


def get_device_info():
    plat_info = platform.platform().split('-')
    if plat_info[0] != "Linux":
        raise Exception(f"Invalid platform: {plat_info[0]}")

    if "aarch64" in plat_info:
        idx = plat_info.index("aarch64")
        device_arch = f"{plat_info[idx - 1]}-{plat_info[idx]}"
        device_sn = jetson_utils.get_jetson_module_sn()
    elif "x86_64" in plat_info:
        idx = plat_info.index("x86_64")
        device_arch = f"{plat_info[idx - 1]}-{plat_info[idx]}"
        device_sn = get_device_sn()
    # 'WSL2-x86_64'
    else:
        raise Exception(f"Invalid device_architecture: {'-'.join(plat_info)}")

    sys_info = {
        "hostname": socket.gethostname(),
        "ip": get_ip(),
        "device_sn": device_sn,
        "device_architecture": device_arch
    }

    node_id = uuid.getnode()
    if node_id == uuid.getnode():
        sys_info["node_id"] = node_id

    return sys_info
#----------------------------------------------------------------------------------------------------------------------------------


def get_device_arch():
    plat_info = platform.platform().split('-')
    if plat_info[0] != "Linux":
        raise Exception(f"Invalid platform: {plat_info[0]}")

    if "aarch64" in plat_info:
        idx = plat_info.index("aarch64")
        return f"{plat_info[idx]}"
    elif "x86_64" in plat_info:
        idx = plat_info.index("x86_64")
        return f"{plat_info[idx]}"
#----------------------------------------------------------------------------------------------------------------------------------


def check_license(license_info):
    device_info = get_device_info()
    # if license_info.get("hostname"):
    #     if device_info["hostname"] != license_info["hostname"]:
    #         raise Exception("Invalid license for device")

    # if license_info.get("ip"):
    #     if device_info["ip"] != license_info["ip"]:
    #         raise Exception("Invalid license for device")

    # if license_info.get("device_architecture"):
    #     if device_info["device_architecture"] != license_info["device_architecture"]:
    #         raise Exception("Invalid license for device")

    if license_info.get("device_sn"):
        if device_info["device_sn"] != license_info["device_sn"]:
            if device_info["device_architecture"] == "generic-x86_64" and not device_info["device_sn"]:
                log.warning("Must run as root")
            else:
                raise Exception("Invalid license for device")

    # if license_info.get("node_id"):
    #     if device_info["node_id"] != license_info["node_id"]:
    #         log.warning("Invalid node_id")
            # raise Exception("Invalid license for device")
#----------------------------------------------------------------------------------------------------------------------------------


def get_edge_data(app_token):
    try:
        log.info(f"Get edge_data")
        endpoint = jwt.decode(app_token, options={"verify_signature": False})['endpoint']
        msg_headers = {'Authorization' : f'Bearer {app_token}'}
        response = requests.get(f"{endpoint}", headers=msg_headers)

        if response.status_code != 200:
            log.error(f"Failing get edge_data: {response.json()}")
            return None

        return response.json()

    except requests.ConnectionError as error:
        log.error(f'Failing get edge_data. Connection error: {error}')
        return None
    except requests.Timeout as error:
        log.error(f'Failing get edge_data. Timeout: {error}')
        return None
    except Exception as excp:
        log.error(f'Failing get edge_data - {excp}')
        return None
#----------------------------------------------------------------------------------------------------------------------------------
