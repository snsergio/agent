#!/bin/bash

export LD_LIBRARY_PATH=/opt/eyeflow/lib:/usr/local/cuda/lib64:/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH
export CUDA_MODULE_LOADING=LAZY

python3 prepare_models.py
./eyeflow_edge --video_save --service
