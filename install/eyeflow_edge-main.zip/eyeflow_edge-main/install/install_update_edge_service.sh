sudo cp update_edge.service /etc/systemd/system/.
sudo cp update_edge.timer /etc/systemd/system/.
sudo systemctl enable update_edge.service
sudo systemctl start update_edge.service
sudo systemctl enable --now update_edge.timer
