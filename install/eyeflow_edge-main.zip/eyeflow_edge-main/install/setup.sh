echo "Edge installation started"

# NVIDIA Driver
sudo apt update && sudo apt upgrade -y

echo "Installing NVIDIA driver"
sudo apt install nvidia-driver-525

echo "Installing Docker"
# Docker
curl https://get.docker.com | sh \
  && sudo systemctl --now enable docker

echo "Installing NVIDIA container"
# NVIDIA Container - online
distribution=$(. /etc/os-release;echo $ID$VERSION_ID) \
      && curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \
      && curl -s -L https://nvidia.github.io/libnvidia-container/$distribution/libnvidia-container.list | \
            sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
            sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

sudo apt update
sudo apt-get install -y nvidia-container-toolkit

# NVIDIA Container - offline
# sudo dpkg -i nvidia-container-toolkit-base_1.13.0-1_amd64.deb nvidia-container-toolkit_1.13.0-1_amd64.deb libnvidia-container1_1.13.0-1_amd64.deb libnvidia-container-tools_1.13.0-1_amd64.deb

sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker

echo "Installing Python libs"
# install python libs
sudo apt install -y python3-pip
sudo -H python3 -m pip install -U \
    pip \
    eyeflow_sdk

# Eyeflow folder & user
# sudo adduser eyeflow
echo "Creating Eyeflow folders"
sudo usermod -a -G docker eyeflow
sudo usermod -a -G users eyeflow

sudo mkdir -p /opt/eyeflow
sudo chown -R eyeflow:users /opt/eyeflow
sudo chmod 775 /opt/eyeflow
sudo chmod g+rwxs /opt/eyeflow
mkdir -p /opt/eyeflow/data
mkdir -p /opt/eyeflow/log
mkdir -p /opt/eyeflow/run
mkdir -p /opt/eyeflow/components
mkdir -p /opt/eyeflow/install

echo "Pulling Edge docker image"
# Docker image
docker pull eyeflowai/eyeflow_edge:latest

# alternative
# gunzip eyeflow_edge.tar.gz
# docker load -i eyeflow_edge.tar

echo "Generating license"
cp * /opt/eyeflow/install/.
cd /opt/eyeflow/install/
python3 request_license

echo "Installing update service"
sh install_update_edge_service.sh
chmod +x stop_edge
chmod +x start_edge
chmod +x update_edge
chmod +x upload_extracts

cp eyeflow_conf.json /opt/eyeflow/run/.
cp run_flow.sh /opt/eyeflow/run/.

echo "Edge installation finished"
